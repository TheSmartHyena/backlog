const myRoutes = require('./../routesTriggers').routes

exports.gardienCrud = async (app, myRequired) => {
    app.post(myRoutes.gardiensCrud, async(req, res)=>{

        const data = req.body

        let result = false
        switch(data.requestType){

            case "readAll":
                result = await gardienReadAll(myRequired)
                break;
            case "read":
                result = await gardienRead(myRequired, data.nni)
                break;
            case "create":
                result = await gardienCreate(myRequired, data.newData)
                break;
            case "update":
                result = await gardienUpdate(myRequired, data.newData)
                break;
            case "delete":
                result =  await gardienDelete(myRequired, data.id)
                break;
            default:
                console.log("Wrong request type");
        }

        res.json({value: result})
    })

}

const gardienReadAll = async (myRequired) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'gardienReadAll')
    }catch(err){
        console.log(err)
        return false
    }

}

const gardienRead = async (myRequired, nni) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'gardienRead', nni)
    }catch(err){
        console.log(err)
        return false
    }

}

const gardienCreate = async (myRequired, newData) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'gardienCreate', [newData.nni, newData.nom, newData.prenom])
    }catch(err){
        console.log(err)
        return false
    }

}

const gardienUpdate = async (myRequired, newData) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'gardienUpdate', [newData.nni, newData.nom, newData.prenom, newData.idgardien])
    }catch(err){
        console.log(err)
        return false
    }

}

const gardienDelete = async (myRequired, id) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'gardienDelete', [id])
    }catch(err){
        console.log(err)
        return false
    }

}

exports.readAll = gardienReadAll
exports.read = gardienRead
exports.create = gardienCreate
exports.update = gardienUpdate
exports.delete = gardienDelete

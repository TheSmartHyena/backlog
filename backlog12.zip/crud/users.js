const myRoutes = require('./../routesTriggers').routes

exports.usersCrud = async (app, myRequired) => {
    app.post(myRoutes.usersCrud, async(req, res)=>{

        const data = req.body
        const sessionData = app.sessions.get(req.session.myId)

        let result = false
        switch(data.requestType){
            case "read":
                result = await usersRead(myRequired, sessionData.userIdService)
                break;
            case "readAll":
                result = await usersReadAll(myRequired)
                break;
            /*case "readForEdit":
                result = await noteServiceReadForEdit(myRequired, sessionData.userIdService, sessionData.userNni)
                break;*/
            case "create":
                console.log(data.newData);
                result = await usersCreate(myRequired, data.newData)
                break;
            case "update":
                result = await usersUpdate(myRequired, data.newData)
                break;
            case "delete":
                result = await usersDelete(myRequired, data.id)
                break;
            default:
                console.log("Wrong request type");
        }

        res.json({value: result})
    })

}

const usersRead = async (myRequired, nni) => {
    try{
        const result =  await myRequired.custom.request.doAnRequest(myRequired,'usersRead', [nni])
        return result
    }catch(err){
        console.log(err)
        return false
    }

}

const usersReadAll = async (myRequired) => {
    try{
        const result =  await myRequired.custom.request.doAnRequest(myRequired,'usersReadAll')
        return result
    }catch(err){
        console.log(err)
        return false
    }

}

/*const usersReadForEdit = async (myRequired, service, nni) => {
    try{
        const result =  await myRequired.custom.request.doAnRequest(myRequired,'noteServiceReadForEdit', [service, nni])
        return result
    }catch(err){
        console.log(err)
        return false
    }

}*/

const usersCreate = async (myRequired, newData) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'usersCreate', [newData.nni, await myRequired.bcrypt.hash(newData.password, 10), newData.nom, newData.prenom, newData.mail, newData.service, newData.entreprise, newData.idgroupe])
    }catch(err){
        console.log(err)
        return false
    }

}

const usersUpdate = async (myRequired, newData) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'usersUpdate', [newData.nni, newData.nom, newData.prenom, newData.mail, newData.service, newData.entreprise, newData.idgroupe, newData.id])
    }catch(err){
        console.log(err)
        return false
    }

}

const usersDelete = async (myRequired, id) => {

    try{
        const result = await myRequired.custom.request.doAnRequest(myRequired,'usersDelete', [id])
        return true
    }catch(err){
        console.log(err)
        return false
    }

}

exports.read = usersRead
exports.readAll = usersReadAll
exports.create = usersCreate
exports.update = usersUpdate
exports.delete = usersDelete

const myRoutes = require('./../routesTriggers').routes

exports.bloquesCrud = async (app, myRequired) => {
    app.post(myRoutes.bloquesCrud, async(req, res)=>{

        const data = req.body

        let result = false
        switch(data.requestType){

            case "readAll":
                result = await bloquesReadAll(myRequired)
                break;
            case "read":
                result = await bloquesRead(myRequired, data.idbloque)
                break;
            case "create":
                result = await bloquesCreate(myRequired, data.newData)
                break;
            case "update":
                result = await bloquesUpdate(myRequired, data.newData)
                break;
            case "delete":
                result =  await bloquesDelete(myRequired, data.idbloque)
                break;
            default:
                console.log("Wrong request type");
        }

        res.json({value: result})
    })

}

const bloquesReadAll = async (myRequired) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'bloquesReadAll')
    }catch(err){
        console.log(err)
        return false
    }

}

const bloquesRead = async (myRequired, idbloque) => {

    try{
        return myRequired.custom.request.doAnRequest(myRequired,'bloquesRead', [idbloque])
    }catch(err){
        console.log(err)
        return false
    }

}

const bloquesCreate = async (myRequired, newData) => {

    try{
        return myRequired.custom.request.doAnRequest(myRequired,'bloquesCreate', [newData.nom, newData.prenom, newData.nni, newData.contammin, newData.contammax])
    }catch(err){
        console.log(err)
        return false
    }

}

const bloquesUpdate = async (myRequired, newData) => {

    try{
        return myRequired.custom.request.doAnRequest(myRequired,'bloquesUpdate', [newData.nom, newData.prenom, newData.nni, newData.contammin, newData.contammax, newData.idbloque])
    }catch(err){
        console.log(err)
        return false
    }

}

const bloquesDelete = async (myRequired, idbloque) => {

    try{
        return myRequired.custom.request.doAnRequest(myRequired,'bloquesDelete', [idbloque])
    }catch(err){
        console.log(err)
        return false
    }

}

exports.readAll = bloquesReadAll
exports.read = bloquesRead
exports.create = bloquesCreate
exports.update = bloquesUpdate
exports.delete = bloquesDelete

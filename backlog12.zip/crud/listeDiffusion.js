const myRoutes = require('./../routesTriggers').routes

exports.listeDiffusionCrud = async (app, myRequired) => {
    app.post(myRoutes.listeDiffusionCrud, async(req, res)=>{

        const data = req.body

        let result = false
        switch(data.requestType){

            case "readAll":
                result = await listeDiffusionReadAll(myRequired)
                break;
            case "read":
                result = await listeDiffusionRead(myRequired, data.idmail)
                break;
            case "create":
                result = await listeDiffusionCreate(myRequired, data.newData)
                break;
            case "update":
                result = await listeDiffusionUpdate(myRequired, data.newData)
                break;
            case "delete":
                result =  await listeDiffusionDelete(myRequired, data.idmail)
                break;
            default:
                console.log("Wrong request type");
        }

        res.json({value: result})
    })

}

const listeDiffusionReadAll = async (myRequired) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'listeDiffusionReadAll')
    }catch(err){
        console.log(err)
        return false
    }

}

const listeDiffusionRead = async (myRequired, idmail) => {

    try{
        return myRequired.custom.request.doAnRequest(myRequired,'listeDiffusionRead', [idmail])
    }catch(err){
        console.log(err)
        return false
    }

}

const listeDiffusionCreate = async (myRequired, newData) => {

    try{
        return myRequired.custom.request.doAnRequest(myRequired,'listeDiffusionCreate', [newData.mail])
    }catch(err){
        console.log(err)
        return false
    }

}

const listeDiffusionUpdate = async (myRequired, newData) => {

    try{
        return myRequired.custom.request.doAnRequest(myRequired,'listeDiffusionUpdate', [newData.idmail, newData.mail])
    }catch(err){
        console.log(err)
        return false
    }

}

const listeDiffusionDelete = async (myRequired, idmail) => {

    try{
        return myRequired.custom.request.doAnRequest(myRequired,'listeDiffusionDelete', [idmail])
    }catch(err){
        console.log(err)
        return false
    }

}

exports.readAll = listeDiffusionReadAll
exports.read = listeDiffusionRead
exports.create = listeDiffusionCreate
exports.update = listeDiffusionUpdate
exports.delete = listeDiffusionDelete

const myRoutes = require('./../routesTriggers').routes

exports.noteServiceCrud = async (app, myRequired) => {
    app.post(myRoutes.noteServiceCrud, async(req, res)=>{

        const data = req.body
        const sessionData = app.sessions.get(req.session.myId)

        let result = false
        switch(data.requestType){
            case "read":
                result = await noteServiceRead(myRequired, sessionData.userIdService)
                break;
            case "readForEdit":
                result = await noteServiceReadForEdit(myRequired, sessionData.userIdService, sessionData.userNni)
                break;
            case "create":
                // data.newData.serviceid = sessionData.userIdService
                data.newData.userNni = sessionData.userNni
                result = await noteServiceCreate(myRequired, data.newData)
                break;
            case "update":
                data.newData.userNni = sessionData.userNni
                result = await noteServiceUpdate(myRequired, data.newData)
                break;
            case "delete":
                result = await noteServiceDelete(myRequired, data.id)
                break;
            default:
                console.log("Wrong request type");
        }

        res.json({value: result})
    })

}

const noteServiceRead = async (myRequired, service) => {
    try{
        const result =  await myRequired.custom.request.doAnRequest(myRequired,'noteServiceRead', [service])
        return result
    }catch(err){
        console.log(err)
        return false
    }

}

const noteServiceReadForEdit = async (myRequired, service, nni) => {
    try{
        const result =  await myRequired.custom.request.doAnRequest(myRequired,'noteServiceReadForEdit', [service, nni])
        return result
    }catch(err){
        console.log(err)
        return false
    }

}

const noteServiceCreate = async (myRequired, newData) => {
    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'noteServiceCreate', [newData.serviceId, newData.note, newData.userNni])
    }catch(err){
        console.log(err)
        return false
    }

}

const noteServiceUpdate = async (myRequired, newData) => {

    try{
        return await myRequired.custom.request.doAnRequest(myRequired,'noteServiceUpdate', [newData.id, newData.serviceId, newData.note, newData.userNni])
    }catch(err){
        console.log(err)
        return false
    }

}

const noteServiceDelete = async (myRequired, id) => {

    try{
        const result = await myRequired.custom.request.doAnRequest(myRequired,'noteServiceDelete', [id])
        console.log(result)
        return true
    }catch(err){
        console.log(err)
        return false
    }

}

exports.read = noteServiceRead
exports.create = noteServiceCreate
exports.update = noteServiceUpdate
exports.delete = noteServiceDelete

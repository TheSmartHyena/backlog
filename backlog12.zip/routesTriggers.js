// Setting routes var to be used dynamically
const routes = {
    index: '/thorium/index',
    stats: '/thorium/stats',
    config: '/thorium/config',
    login: '/thorium/login',
    logout: '/thorium/logout',
    configList: '/config/list',
    requests: '/config/requests',
    request: '/thorium/request',
    noteService: '/thorium/noteService',
    statsService: '/thorium/stats/service',
    statsEntreprise: '/thorium/stats/entreprise',
    c3: '/thorium/c3',

    users: '/users/list',
    usersCreate: '/users/create',
    usersUpdatePassword: '/users/updatePassword',

    gardiensCrud: '/thorium/config/gardiens/crud',
    bloquesCrud: '/thorium/config/bloques/crud',
    listeDiffusionCrud: '/thorium/config/listeDiffusion/crud',
    noteServiceCrud: '/thorium/config/noteService/crud',
    usersCrud: '/thorium/config/users/crud',
    c3Crud: '/thorium/config/c3/crud',

    nbContaminedPerDay: '/thorium/request/nbContaminedPerDay',
    passesPerDay: '/thorium/request/passesPerDay',
    nbContaminedPerMonth: '/thorium/request/nbContaminedPerMonth',
    nbContaminedPerBuildingPerDay: '/thorium/request/nbContaminedPerBuildingPerDay',
    getAllData: '/thorium/request/getAllData',
    getAllUsers: '/thorium/request/getAllUsers',
    selectByBat: '/thorium/request/selectByBat',
    getDataByConfig: '/thorium/request/dataByConfig',

    default: '/thorium/index'
}

// Setting triggers for middlewares
const checkSessionTriggers = new Set()
checkSessionTriggers.add(routes.index)
checkSessionTriggers.add(routes.stats)
checkSessionTriggers.add(routes.users)
checkSessionTriggers.add(routes.config)
checkSessionTriggers.add(routes.configList)
checkSessionTriggers.add(routes.usersCreate)
checkSessionTriggers.add(routes.usersUpdatePassword)
checkSessionTriggers.add(routes.gardiensCrud)
checkSessionTriggers.add(routes.nbContaminedPerDay)
checkSessionTriggers.add(routes.passesPerDay)
checkSessionTriggers.add(routes.nbContaminedPerMonth)
checkSessionTriggers.add(routes.nbContaminedPerBuildingPerDay)
checkSessionTriggers.add(routes.getAllData)
checkSessionTriggers.add(routes.getAllUsers)
checkSessionTriggers.add(routes.selectByBat)
checkSessionTriggers.add(routes.gardiensCrud)
checkSessionTriggers.add(routes.bloquesCrud)
checkSessionTriggers.add(routes.listeDiffusionCrud)
checkSessionTriggers.add(routes.noteService)
checkSessionTriggers.add(routes.noteServiceCrud)
checkSessionTriggers.add(routes.usersCrud)
checkSessionTriggers.add(routes.statsService)
checkSessionTriggers.add(routes.statsEntreprise)
checkSessionTriggers.add(routes.c3)
checkSessionTriggers.add(routes.c3Crud)
checkSessionTriggers.add(routes.getDataByConfig)


const checkRolesTriggers = new Set()
checkRolesTriggers.add(routes.stats)
checkRolesTriggers.add(routes.users)
checkRolesTriggers.add(routes.config)
checkRolesTriggers.add(routes.configList)
checkRolesTriggers.add(routes.usersCreate)
checkRolesTriggers.add(routes.usersUpdatePassword)
checkRolesTriggers.add(routes.gardiensCrud)
checkRolesTriggers.add(routes.nbContaminedPerDay)
checkRolesTriggers.add(routes.passesPerDay)
checkRolesTriggers.add(routes.nbContaminedPerMonth)
checkRolesTriggers.add(routes.nbContaminedPerBuildingPerDay)
checkRolesTriggers.add(routes.getAllData)
checkRolesTriggers.add(routes.getAllUsers)
checkRolesTriggers.add(routes.selectByBat)
checkRolesTriggers.add(routes.gardiensCrud)
checkRolesTriggers.add(routes.bloquesCrud)
checkRolesTriggers.add(routes.listeDiffusionCrud)
checkRolesTriggers.add(routes.noteService)
checkRolesTriggers.add(routes.noteServiceCrud)
checkRolesTriggers.add(routes.usersCrud)
checkRolesTriggers.add(routes.statsService)
checkRolesTriggers.add(routes.statsEntreprise)
checkRolesTriggers.add(routes.c3)
checkRolesTriggers.add(routes.c3Crud)
checkRolesTriggers.add(routes.getDataByConfig)

const checkPasswordTriggers = new Set()

// for routes, sets allowed group for each routes
// 1 admin, 2 user lambda
const routeAllowedGroup = new Map()
routeAllowedGroup.set(routes.stats, new Set([1, 2]))
routeAllowedGroup.set(routes.users, new Set([1]))
routeAllowedGroup.set(routes.config, new Set([1]))
routeAllowedGroup.set(routes.configList, new Set([1]))
routeAllowedGroup.set(routes.usersCreate, new Set([1]))
routeAllowedGroup.set(routes.usersUpdatePassword, new Set([1]))
routeAllowedGroup.set(routes.gardiensCrud, new Set([1]))
routeAllowedGroup.set(routes.nbContaminedPerDay, new Set([1,2]))
routeAllowedGroup.set(routes.passesPerDay, new Set([1,2]))
routeAllowedGroup.set(routes.nbContaminedPerMonth, new Set([1,2]))
routeAllowedGroup.set(routes.nbContaminedPerBuildingPerDay, new Set([1,2]))
routeAllowedGroup.set(routes.getAllData, new Set([1,2]))
routeAllowedGroup.set(routes.getAllUsers, new Set([1,2]))
routeAllowedGroup.set(routes.selectByBat, new Set([1,2]))
routeAllowedGroup.set(routes.gardiensCrud, new Set([1]))
routeAllowedGroup.set(routes.bloquesCrud, new Set([1]))
routeAllowedGroup.set(routes.listeDiffusionCrud, new Set([1]))
routeAllowedGroup.set(routes.noteService, new Set([1, 2]))
routeAllowedGroup.set(routes.noteServiceCrud, new Set([1, 2]))
routeAllowedGroup.set(routes.usersCrud, new Set([1]))
routeAllowedGroup.set(routes.statsService, new Set([1, 2]))
routeAllowedGroup.set(routes.statsEntreprise, new Set([1, 2]))
routeAllowedGroup.set(routes.c3, new Set([1, 2]))
routeAllowedGroup.set(routes.c3Crud, new Set([1, 2]))
routeAllowedGroup.set(routes.getDataByConfig, new Set([1, 2]))

exports.routes = routes
exports.checkSessionTriggers = checkSessionTriggers
exports.checkRolesTriggers = checkRolesTriggers
exports.checkPasswordTriggers = checkPasswordTriggers
exports.routeAllowedGroup = routeAllowedGroup
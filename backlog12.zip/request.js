const mySqlRequests = require('./sqlRequests')
const myRoutes = require('./routesTriggers').routes

exports.doAnRequest = async (myRequired, key, params=[]) => {
    return new Promise(async (resolve, reject)=>{

        const data = {request: {
                key: key,
                params: params
            }}

        const hash = `$2a$10$KaQmvu9t7CDQ49LWtyuRc.mP4EOcg/TUjijFD.Ej8Cg0DeixipitO`
        const toSend = {data: data, hash: hash}

        await myRequired.axios.post('http://localhost:3000/thorium/request', toSend)
            .then((response)=>{
                resolve(response.data)
            })
            .catch((err)=>{
                reject(err)
            })
    })
}

exports.get_request = (app, pool) => {

    app.post(myRoutes.request, async (req, res)=>{

        const requestData = req.body.data.request
        const sql = await mySqlRequests.getRequest(app, requestData.key)

        // execute the query
        const client = await pool.connect()

        try{
            const result = await client.query(sql, requestData.params)
            await client.release()
            await res.json(result.rows)
        }catch(e){
            console.log(e.stack)
        }/*finally{
        await client.release()
        }*/

    })

}
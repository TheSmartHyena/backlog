const myRoutes = require('./routesTriggers').routes

exports.get_sqlRequestsList = (app, myRequired) => {

    app.get(myRoutes.configList, async (req, res)=>{

        let result = []
        await myRequired.storage.forEach(function(item) {
            result.push([item.key, [item.key, item.value]])
        });

        res.render('configList', {dataTest: result, navbarBool: res.navbarBool})

    })

}
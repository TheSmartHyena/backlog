/*const Pool = require('pg')
const bcrypt = require('bcryptjs')
const bodyParser = require('body-parser')
const axios = require('axios').default // for test purpose
const express = require('express')
const storage = require('node-persist')
const pug = require('pug')
const session = require('express-session')
const uuidv1 = require('uuid/v1')
const cookieParser = require('cookie-parser')
const nodecache = require("node-cache")
const argon2Pass = require('argon2-pass') // for later ota
*/

exports.required = {

    pg: require('pg'),
    bcrypt: require('bcryptjs'),
    bodyParser: require('body-parser'),
    axios: require('axios'),
    express: require('express'),
    storage: require('node-persist'),
    pug: require('pug'),
    session: require('express-session'),
    uuidv1: require('uuid/v1'),
    cookieParser: require('cookie-parser'),
    nodecache: require("node-cache"),
    argon2Pass:  require('argon2-pass'),
    noUi:  require('nouislider'),

}
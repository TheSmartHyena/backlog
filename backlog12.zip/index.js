// Public modules
const myRequired = require('./npmRequires').required

const app = myRequired.express()
const initAll = async () => {

    await myRequired.storage.init( {
        stringify: JSON.stringify,
        parse: JSON.parse,
        encoding: 'utf8',
        logging: false
    })

    app.storage = myRequired.storage
    app.bcrypt = myRequired.bcrypt

}

initAll()

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(myRequired.bodyParser.urlencoded({ extended: true }))
app.use(myRequired.bodyParser.json())

// Set templating with PUG
app.set('view engine', 'pug')
// https://pugjs.org/api/getting-started.html

app.use(myRequired.cookieParser())
app.use(myRequired.session({
    genid: function(req) {
        return myRequired.uuidv1() // use UUIDs for session IDs
    },
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // if https only
}))

const sessions = new myRequired.nodecache({stdTTL: 14400, checkperiod: 240})
app.sessions = sessions

const config = {
    user: 'postgres',
    host: '10.168.24.183',
    database: 'thorium_test',
    password: 'root',
    port: 5432,
}

const pool = new myRequired.pg.Pool(config)
pool.on('error', (err, client) => {
    console.error('Unexpected error on idle client', err)
    process.exit(-1)
})

// My modules
const myMiddlewares = require('./middlewares')
const myRequest = require('./request')
const myRequestClean = require('./requestClean')
const mySqlRequests = require('./sqlRequests')
const myRoutesTriggers = require('./routesTriggers')
const myAuth = require('./auth')
const myConfig = require('./config')

myRequired.custom = {
    request : myRequest
}

// My Cruds
const myCruds = {
    gardien : require('./crud/gardien'),
    bloques : require('./crud/bloques'),
    listeDiffusion : require('./crud/listeDiffusion'),
    noteService : require('./crud/noteService'),
    users: require('./crud/users'),
}

const myRoutes = myRoutesTriggers.routes

// Applying them
app.use(myMiddlewares.checkPassword(app))
app.use(myMiddlewares.checkSession(app))
app.use(myMiddlewares.checkRoles(app))
app.use(myMiddlewares.navbarElements(app))
app.use(myMiddlewares.redirectIfLogged(app))

// Exposing assets
app.use(myRequired.express.static('views/assets'))

/**
 * Sql Requests, locally stored
 **/
mySqlRequests.get_requests(app, myRequired)
mySqlRequests.post_requests(app, myRequired)

/**
 * Request part
 **/
myRequest.get_request(app, pool)

/**
 * Auth part
 **/
myAuth.get_logout(app, myRequired)
myAuth.get_login(app)
myAuth.post_login(app, myRequired)

/**
 * Config part
 **/
myConfig.get_sqlRequestsList(app, myRequired)

/**
 * APi données "Clean" ou non-brut
 **/
myRequestClean.get_nbContaminedPerDay(app, myRequired)
myRequestClean.get_passesPerDay(app, myRequired)
myRequestClean.get_nbContaminedPerMonth(app, myRequired)
myRequestClean.get_nbContaminedPerBuildingPerDay(app, myRequired)
myRequestClean.get_getAllData(app, myRequired)
myRequestClean.get_getAllUsers(app, myRequired)
myRequestClean.get_selectByBat(app, myRequired)

myRequestClean.post_getDataByConfig(app, myRequired)

/**
 * CRUD Gardien
 */
myCruds.gardien.gardienCrud(app, myRequired)

/**
 * CRUD Bloqués
 */
myCruds.bloques.bloquesCrud(app, myRequired)

/**
 * CRUD Liste de diffusion
 */
myCruds.listeDiffusion.listeDiffusionCrud(app, myRequired)

/**
 * CRUD Note de service
 */
myCruds.noteService.noteServiceCrud(app, myRequired)

/**
 * CRUD users
 */
myCruds.users.usersCrud(app, myRequired)

app.post('/thorium/user/create', async (req, res)=>{

})

app.post('/thorium/user/update', async (req, res)=>{

})

app.post(myRoutes.gardiensCrud, async (req, res)=>{
    const data = req.body
})

/**
* Thorium WEB - Get request
**/

app.get(myRoutes.index, async (req, res)=>{
    res.render('thoriumIndex', {navbarBool: res.navbarBool})
})

app.get(myRoutes.stats, async (req, res)=>{
    res.render('thoriumStats', {navbarBool: res.navbarBool})
})

app.get(myRoutes.users, async (req, res)=>{
    res.render('thoriumUsers', {navbarBool: res.navbarBool})
})

app.get(myRoutes.config, async (req, res)=>{
    res.render('thoriumConfig', {navbarBool: res.navbarBool})
})

app.get(myRoutes.noteService, async (req, res)=>{
    res.render('thoriumNoteService', {navbarBool: res.navbarBool})
})

app.get(myRoutes.usersCreate, async (req, res)=>{
    res.render('usersCreate', {navbarBool: res.navbarBool})
})

app.get(myRoutes.usersUpdatePassword, async (req, res)=>{
    res.render('usersUpdatePassword', {navbarBool: res.navbarBool})
})

app.get(myRoutes.c3, async (req, res)=>{
    res.render('thoriumC3', {navbarBool: res.navbarBool})
})

app.get(myRoutes.statsService, async (req, res)=>{
    res.render('thoriumStatsService', {navbarBool: res.navbarBool})
})

app.get(myRoutes.statsEntreprise, async (req, res)=>{
    res.render('thoriumStatsEntreprise', {navbarBool: res.navbarBool})
})

app.use(function(req, res, next) {

    // isConnected is not to state login but just display or not the disconnect btn
    const navbarBool = {
        isLogin: false,
        isAdmin: false,
        isUser: false
    }

    res.status(404).render('404', {navbarBool: navbarBool})

});

/*
    RUN THE APP
*/
app.listen(3000, function () {
    console.log('Example app listening on port 3000!')
})
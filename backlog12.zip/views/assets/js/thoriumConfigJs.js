/**
 * CRUD Gardien
 */
async function gardienReadAll(){

    try{
        const result = await createPostPromise(myRoutes.gardiensCrud, {requestType: "readAll"});
        // console.log(result);
        return result;
    }catch(err){
        console.log(err)
    }

}

async function gardienRead(nni){

    try{
        const result = await createPostPromise(myRoutes.gardiensCrud, {requestType: "read", data: {nni: nni}});
        //console.log(result);
        return result;
    }catch(err){
        console.log(err)
    }

}

/**
 * CRUD Bloqués
 */
async function bloquesReadAll(){

    try{
        const result = await createPostPromise(myRoutes.bloquesCrud, {requestType: "readAll"});
        //console.log(result);
        return result;
    }catch(err){
        console.log(err)
    }

}

/**
 * CRUD Liste diffusion
 */
async function listeDiffusionReadAll(){

    try{
        return await createPostPromise(myRoutes.listeDiffusionCrud, {requestType: "readAll"});
    }catch(err){
        console.log(err)
    }

}

/**
 * Render Partie
 */
function renderAll(){

    renderGardien();
    renderBloques();
    renderlisteDiffusion();
}

async function renderGardien(){
    const gardien = await gardienReadAll();
    const result = objToArrayMapGardien(gardien[1].value);
    gardienList.load(result);
    gardienList.render();
    window.gardienList = gardienList;
}

async function renderBloques(){

    const bloques = await bloquesReadAll();
    //console.log(bloques)
    const result = objToArrayMapBloques(bloques[1].value);
    bloquesList.load(result);
    bloquesList.render();
    window.bloquesList = bloquesList;

}

async function renderlisteDiffusion(){
    const listeDiffusion = await listeDiffusionReadAll();
    const result = objToArrayMapListeDiffusion(listeDiffusion[1].value);
    listeDiffusionList.load(result);
    listeDiffusionList.render();
    window.listeDiffusionList = listeDiffusionList;
}

/**
 * Les 3 tableaux
 */
let bloquesList = (function () {

    const config = {
        nbCol: 5,
        divId: "bloquesList",
        btnSize: "sm",
        modalRowEditTitle: "Modification d'un bloqué",
        modalRowAddTitle: "Ajout d'un bloqué",
        modalRowDelTitle: "Supression d'un bloqué",
        modalDelId: "modal_row_del_bloques"
    };
    const modalId = {
        row: "modal_row_bloques",
        col: "modal_col"
    }

    const result = new SimpleTableEditorWrapperBloques(config, [], ["Nom", "Prénom", "Nni", "Contamination Min", "Contamination Max"], "bloquesList", modalId);
    result.allowRowAdd(false);
    result.allowRowEdit(false);
    result.allowRowDel(true);

    return result;

})();

let gardienList = (function () {

    const config = {
        nbCol: 3,
        divId: "gardienList",
        btnSize: "sm",
        modalRowEditTitle: "Modification d'un gardien",
        modalRowAddTitle: "Ajout d'un gardien",
        modalRowDelTitle: "Supression d'un gardien",
        modalDelId: "modal_row_del_gardien"
    };
    const modalId = {
        row: "modal_row_gardien",
        col: "modal_col"
    }

    const result = new SimpleTableEditorWrapperGardien(config, [], ["Nni", "Nom", "Prénom"], "gardienList", modalId);
    result.allowRowEdit(true);
    result.allowRowAdd(true);
    result.allowRowDel(true);

    return result;

})();

let listeDiffusionList = (function () {

    const config = {
        nbCol: 1,
        divId: "listeDiffusionList",
        btnSize: "sm",
        modalRowEditTitle: "Modification d'une adresse mail",
        modalRowAddTitle: "Ajout d'une adresse mail",
        modalRowDelTitle: "Supression d'une adresse mail",
        modalDelId: "modal_row_del_listeDiffusion"
    };
    const modalId = {
        row: "modal_row_listeDiffusion",
        col: "modal_col"
    }

    const result = new SimpleTableEditorWrapperListeDiffusion(config, [], ["mail"], "listeDiffusionList", modalId);

    result.allowRowAdd(true);
    result.allowRowEdit(true);
    result.allowRowDel(true);

    return result;

})();

function objToArrayMapBloques(objs){

    const result = [];
    for(obj of objs){
        result.push(["", [obj.nom, obj.prenom, obj.nni, obj.contammin, obj.contammax, obj.idbloque]]);
    }

    return result;

}

function objToArrayMapGardien(objs){

    const result = [];
    for(obj of objs){
        result.push(["", [obj.nni, obj.nom, obj.prenom, obj.idgardien]]);
    }

    return result;

}

function objToArrayMapListeDiffusion(objs){

    const result = [];
    for(obj of objs){
        result.push(["", [obj.mail, obj.idmail]]);
    }

    return result;

}


function updateBloques() {
    // $.post("/requests", {items: JSON.stringify(window.tableEditorRequests.export())});
}

function updateGardien() {
    // $.post("/requests", {items: JSON.stringify(window.tableEditorRequests.export())});
}
function updateListeDiffusion() {
    // $.post("/requests", {items: JSON.stringify(window.tableEditorRequests.export())});
}
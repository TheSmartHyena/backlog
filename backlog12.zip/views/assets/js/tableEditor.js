/* 
    CONFIG {}

    - divId
    - nbCol

*/

/* 
    Data: [
        key, [col1, col2, col3], 
        key2, [col1, col2, col3], 
        key3, [col1, col2, col3]
    ]
*/

// externalVarName ==> the name of the instance, wich will be used to use the class

class TableEditor{
    constructor(config, data = [], header, externalVarName){

        let myAllowRowMove = true;
        let myAllowRowAdd = true;
        let myAllowRowEdit = true;
        let myAllowRowDel = true;

        let myAllowColMove = false;
        let myAllowColAdd = false;
        let myAllowColEdit = false;
        let myAllowColDel = false;

        // associate a key with it's row number ==> fasten edit
        let keyIndex = new Map();
        this.keyIndex = function(){
            return keyIndex;
        }

        let myData = data ? data : [];
        this.data = function(){
            return myData;
        }
        
        this.load = function (data){
            myData = data ? data : [];
            if(myData.length > 0){
                for(let i=0; i < myData.length; i++){
                    keyIndex.set(myData[i][0], i);
                }
            }
        }

        function guidGenerator() {
            let S4 = function() {
               return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
            };
            return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
        }
        
        this.release = function(){
            document.getElementById(config.divId).innerHTML = "";
        }

        this.export = function(){
            return myData;
        }

        this.edit = function(key, newValues){
            
            if(myAllowRowEdit){
                if(keyIndex.has(key)){
                    if(newValues.length == config.nbCol){
                        myData[keyIndex.get(key)][1] = newValues;
                        this.render();
                    }else{
                        console.log("Number of columns does not match");
                    }
                }else{
                    console.log("Selected key does not exist");
                }
            }else{
                console.log("Action currently locked");
            }

        }

        this.render = function(){

            let headerStart = '<div class="table-wrapper"><div class="table-scroll"><table class="table table-striped text-center maxHeighted"><thead><tr>';
            let headerEnd = '</tr></thead>';

            let bodyStart = '<tbody>';
            let bodyEnd = '</tbody></table> </div></div>';
                
            let headerContent = '';
            for(let i = 0; i < config.nbCol; i++){
                headerContent = headerContent + '<th>' + header[i] + '</th>';
            }

            if(myAllowColAdd && config.nbCol === 0){
                headerContent = headerContent + '<th> --- </th>';
            }

            if(myAllowRowAdd && myData.length === 0){
                headerContent = headerContent + '<th> Contrôles </th>';
            }

            if((myAllowRowEdit || myAllowRowMove || myAllowRowDel || myAllowRowAdd) && myData.length > 0){
                headerContent = headerContent + '<th> Contrôles </th>';
            }
            
            let bodyContent = '';
            for(let i = 0; i < myData.length; i++){

                bodyContent = bodyContent + '<tr>';
                for(let j = 0; j < config.nbCol; j++){
                    bodyContent = bodyContent + '<td>' + myData[i][1][j] + '</td>';
                }

                if(config.nbCol === 0){
                    bodyContent = bodyContent + '<td> --- </td>';
                }

                if(myAllowRowEdit || myAllowRowMove || myAllowRowDel || myAllowRowAdd){
                    bodyContent = bodyContent + '<td class="text-center">' + generateRowControls(myData[i][0]) + '</td>';
                }
                    
                bodyContent = bodyContent + '<tr>';
            }

            let lastRowWithControls = generateColControls();

            const tableHtml = headerStart + headerContent + headerEnd + bodyStart + bodyContent + lastRowWithControls + bodyEnd;

            document.getElementById(config.divId).innerHTML = tableHtml;

        }

        function generateRowControls(key, size="sm"){

            let result = '';
            if(myAllowRowEdit && config.nbCol > 0){
                result = result + `<button type="button" class="btn btn-warning btn-${config.btnSize}" onclick="window.${externalVarName}.showRowEdit('${key}');"> <i class="fas fa-edit"></i> </button>`;
            }

            if(myAllowRowMove){
                result = result + `<button type="button" class="btn btn-primary btn-${config.btnSize}" onclick="window.${externalVarName}.rowDown('${key}');"> <i class="fas fa-arrow-down"></i> </button>`;
                result = result + `<button type="button" class="btn btn-primary btn-${config.btnSize}" onclick="window.${externalVarName}.rowUp('${key}');"> <i class="fas fa-arrow-up"></i> </button>`;
            }

            if(myAllowRowDel){
                result = result + `<button type="button" class="btn btn-danger btn-${config.btnSize}" onclick="window.${externalVarName}.rowDel('${key}');"> <i class="fas fa-trash-alt"></i> </button>`;
            }  

            if(myAllowRowAdd){
                result = result + `<button type="button" class="btn btn-success btn-${config.btnSize}" onclick="window.${externalVarName}.showRowAdd('${key}');"> <i class="fas fa-plus"></i> </button>`;
            }   

            if(myAllowRowEdit || myAllowRowMove || myAllowRowDel || myAllowRowAdd){
                result = '<div class="btn-group">' + result + '</div>';
            }

            return result;
        }

        function generateColControls(){

            let result = "";
            if(myAllowColMove || myAllowColAdd || myAllowColDel || myAllowColEdit){

                for(let i = 0; i < config.nbCol; i++){
                    result = result + '<td class="text-center">' + getColControls(i) + '</td>';
                }

                if(myAllowColAdd && config.nbCol === 0){
                    result = result + '<td class="text-center">' + getColControlsNoCol() + '</td>';
                }

                if(myAllowRowAdd && myData.length === 0){
                    result = result + '<td class="text-center">' + getColControlsNoRow() + '</td>';
                }

                result = '<tr>' + result + '</tr>';

            }else if(myAllowRowAdd && myData.length === 0){

                for(let i = 0; i < config.nbCol; i++){
                    result = result + '<td class="text-center"> --- </td>';
                }

                result = result + '<td class="text-center">' + getColControlsNoRow() + '</td>';
                result = '<tr>' + result + '</tr>';

            }

            return result;

        }

        function getColControls(index){

            let result = '';

            if(myAllowColEdit && config.nbCol > 0){
                result = result + `<button type="button" class="btn btn-warning btn-${config.btnSize}" onclick="window.${externalVarName}.showColEdit('${index}');"> <i class="fas fa-edit"></i> </button>`;
            }

            if(myAllowColMove){
                result = result + `<button type="button" class="btn btn-primary btn-${config.btnSize}" onclick="window.${externalVarName}.colLeft('${index}');"> <i class="fas fa-arrow-left"></i> </button>`;
                result = result + `<button type="button" class="btn btn-primary btn-${config.btnSize}" onclick="window.${externalVarName}.colRight('${index}');"> <i class="fas fa-arrow-right"></i> </button>`;
            }
            
            if(myAllowColDel){
                result = result + `<button type="button" class="btn btn-danger btn-${config.btnSize}" onclick="window.${externalVarName}.colDel('${index}');"> <i class="fas fa-trash-alt"></i> </button>`;
            }

            if(myAllowColAdd){
                result = result + `<button type="button" class="btn btn-success btn-${config.btnSize}" onclick="window.${externalVarName}.showColAdd('${index}');"> <i class="fas fa-plus"></i> </button>`;
            }

            if(myAllowColMove || myAllowColDel || myAllowColAdd){
                result = '<div class="btn-group-vertical">' + result + '</div>';
            }

            return result;
        
        }

        function getColControlsNoRow(){

            let result = '';
            if(myAllowRowAdd && config.nbCol > 0){
                result = result + '<div class="btn-group">' + `<button type="button" class="btn btn-success btn-${config.btnSize}" onclick="window.${externalVarName}.showRowAdd();"> <i class="fas fa-plus"></i> </button>` + '</div>';
            }  

            return  result;
        }

        function getColControlsNoCol(){

            let result = "";
            if(myAllowColAdd){
                result = result + '<div class="btn-group">' + `<button type="button" class="btn btn-success btn-${config.btnSize}" onclick="window.${externalVarName}.colAdd();"> <i class="fas fa-plus"></i> </button>` + '</div>';
            }

            return result;
        }

        // lock-unlock
        this.allowColMove = function(bool){
            myAllowColMove = bool;
        }

        this.allowRowMove = function(bool){
            myAllowRowMove = bool;
        }

        this.allowRowEdit = function(bool){
            myAllowRowEdit = bool;
        }

        this.allowColEdit = function(bool){
            myAllowColEdit = bool;
        }

        this.allowRowAdd = function(bool){
            myAllowRowAdd = bool;
        }

        this.allowRowDel = function(bool){
            myAllowRowDel = bool;
        }

        this.allowColAdd = function(bool){
            myAllowColAdd = bool;
        }

        this.allowColDel = function(bool){
            myAllowColDel = bool;
        }
        

        // Rows
        this.rowUp = function(key){

            if(myAllowRowMove){
                if(keyIndex.has(key)){
                    if(keyIndex.get(key) > 0){
                        
                        // A ==> selected key index
                        // B ==> future selected key index
                        const indexA = keyIndex.get(key);
                        const indexB = keyIndex.get(key)-1;

                        let temp = myData[indexA];
                        myData[indexA] = myData[indexB];
                        myData[indexB] = temp;

                        keyIndex.set(myData[indexA][0], indexA);
                        keyIndex.set(key, indexB);
                        
                        // keyIndex.forEach((value, key)=>{
                        //     console.log(key + " - " + value);
                        // });
                        this.render();

                    }else{
                        console.log("Already at top");
                    }
                }else{
                    console.log("The row selected does not exist");
                }
            }else{
                console.log("Action currenlty locked");
            }

        }

        this.rowDown = function(key){
            
            if(myAllowRowMove){
                if(keyIndex.has(key)){
                    if(keyIndex.get(key) < (keyIndex.size - 1)){
                        
                        // A ==> selected key index
                        // B ==> future selected key index
                        const indexA = keyIndex.get(key);
                        const indexB = keyIndex.get(key)+1;

                        let temp = myData[indexA];
                        myData[indexA] = myData[indexB];
                        myData[indexB] = temp;

                        keyIndex.set(myData[indexA][0], indexA);
                        keyIndex.set(key, indexB);
                        
                        // keyIndex.forEach((value, key)=>{
                        //     console.log(key + " - " + value);
                        // });
                        this.render();

                    }else{
                        console.log("Already at dow");
                    }
                }else{
                    console.log("The row selected does not exist");
                }
            }else{
                console.log("Action currently locked");
            }

        }

        this.rowAdd = function(values, keyToInsertAfter=false){

            if(myAllowRowAdd){
                if(values.length == config.nbCol){
                    
                    let key = guidGenerator();
                    let newArr = [key, values];

                    myData[myData.length] = newArr;
                    keyIndex.set(key, myData.length -1);

                    this.render();

                    return key;

                }else{
                    console.log("Number of columns does not match");
                    return false;
                }
            }else{
                console.log("Action currently locked");
            }

        }

        this.rowDel = function(key){

            if(myAllowRowDel){
                if(keyIndex.has(key)){

                    myData.splice(keyIndex.get(key), 1);

                    keyIndex.clear();
                    if(myData.length > 0){
                        for(let i=0; i < myData.length; i++){
                            keyIndex.set(myData[i][0], i);
                        }
                    }

                    // keyIndex.forEach((value, key)=>{
                    //     console.log(key + " - " + value);
                    // });
                    this.render();

                }else{  
                    console.log("Selected key does not exist");
                }
            }else{
                console.log("Action currently locked");
            }

        }

        // Columns
        this.colAdd = function(defaultValue = "", headerTitle="", index=-1){

            if(myAllowColAdd){
                config.nbCol++;
                for(let i=0; i<myData.length; i++){
                    myData[i][1].push(defaultValue);
                }
                header.push(headerTitle);
                this.render();
            }else{
                console.log("Action currently locked");
            }

        }

        this.colDel = function(index){
            if(myAllowColDel){
                if(index < 0 || index > (config.nbCol-1)){
                    console.log("Index is out of range");
                }else{
                    config.nbCol--;
                    for(let i=0; i<myData.length; i++){
                        myData[i][1].splice(index, 1);
                    }
                    header.splice(index, 1);
                    this.render();
                }
            }else{
                console.log("Action currently locked");
            }
        }

        this.colLeft = function(index){

            index = Number(index);
            if(myAllowColMove){
                if(index < 1 || index > (config.nbCol-1)){
                    console.log("Index is out of range");
                }else{
                    for(let i=0; i<myData.length; i++){
                        let temp = myData[i][1][index];
                        myData[i][1][index] = myData[i][1][index-1];
                        myData[i][1][index-1] = temp;
                    }
                    this.render();
                }
            }else{
                console.log("Action currently locked");
            }

        }

        this.colRight = function(index){

            index = Number(index);
            if(myAllowColMove){
                if(index < 0 || index >= (config.nbCol-1)){
                    console.log("Index is out of range");
                }else{
                    for(let i=0; i<myData.length; i++){
                        let temp = myData[i][1][index];
                        myData[i][1][index] = myData[i][1][index+1];
                        myData[i][1][index+1] = temp;
                    }
                    this.render();
                }
            }else{
                console.log("Action currently locked");
            }

        }

        // this.keyIndex = keyIndex;

    }

}





// const config = {
//     divId: "collll",
//     nbCol: 3
// };

// const dataTest = [
//     ["drdrgdrg", ["sefsef", "sefsef", "sefse"]],
//     ["drgdrgdrgdrgdrg",["efsyèiyiyèi", "sefseyiyèiyèif", "yiyèiyèiy_iyèi"]],
//     ["3630",["5885555", "999999", "7897987987"]]
// ];

// const test = new TableEditor(config, [], ["a", "b", "c"]);

// test.rowUp("3630");
// test.rowUp("3630");
// test.rowUp("3630");

// test.rowDown("3630");
// test.rowDown("3630");
// test.rowDown("3630");

// test.edit("3630", ["sf", "sefsef"]);
// test.edit("3630", ["123456", "123456", "rien ? "]);

// const key = test.rowAdd(["ef", "ef"]);

// const a = test.rowAdd(["111", "222", "333"]);
// const b = test.rowAdd(["444", "555", "666"]);
// const c = test.rowAdd(["777", "888", "999"]);

// console.log(a);
// console.log(b);
// console.log(c);

// test.rowUp(c);
// test.rowUp(c);
// test.rowDown(a);

// test.rowDel(c);
// test.colAdd();
// test.allowColadd(true);
// test.colAdd("poulet");

// const d = test.rowAdd(["111", "000", "000", "0000"]);
// test.rowUp(d);
// test.rowUp(d);

// // test.colDel(0);
// test.colDel(3);

// test.allowColMove(true);
// test.colLeft(2);
// test.colLeft(1);
// test.colLeft(2);

// test.colRight(0);
// test.colRight(1);
// test.colRight(0);

// console.log(test.export());


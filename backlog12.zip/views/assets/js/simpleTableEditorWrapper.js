class SimpleTableEditorWrapperGardien extends SimpleTableEditor{
    constructor(config, myData = [], header, externalVarName, modalId){
        super(config, myData, header, externalVarName);

        const mySuperKeyIndex = super.keyIndex();

        this.showRowAdd = function(key){
            document.getElementById(modalId.row + "_title").innerText = config.modalRowAddTitle;

            document.getElementById(modalId.row + "_nni").value = "";
            document.getElementById(modalId.row + "_nom").value = "";
            document.getElementById(modalId.row + "_prenom").value = "";


            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowAdd('${key}');"> Valider la création</button>`;
            document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            $("#" + modalId.row).modal("show");
        }

        this.showRowEdit = function(key){

            document.getElementById(modalId.row + "_title").innerText = config.modalRowEditTitle;

            if(this.keyIndex().has(key)){
                document.getElementById(modalId.row + "_nni").value = this.data()[this.keyIndex().get(key)][1][0];
                document.getElementById(modalId.row + "_nom").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_prenom").value = this.data()[this.keyIndex().get(key)][1][2];

                const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowEdit('${key}');"> Valider l'édition</button>`;
                document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            }else{
                document.getElementById(modalId.row + "_txt").value = "Error";
            }

            $("#" + modalId.row).modal("show");

        }

        this.showRowDel = function(key){
            document.getElementById(config.modalDelId + "_title").innerText = config.modalRowDelTitle;

            document.getElementById(config.modalDelId + "_nni").value = this.data()[this.keyIndex().get(key)][1][0];
            document.getElementById(config.modalDelId + "_nom").value = this.data()[this.keyIndex().get(key)][1][1];
            document.getElementById(config.modalDelId + "_prenom").value = this.data()[this.keyIndex().get(key)][1][2];

            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowDel('${key}');"> Valider la suppression </button>`;
            document.getElementById(config.modalDelId + "_validate").innerHTML = htmlValue;
            $("#" + config.modalDelId).modal("show");
        }

        this.validateRowAdd = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_nni");
            values[1] = _get(modalId.row + "_nom");
            values[2] = _get(modalId.row + "_prenom");

            // request db
            try{
                const result = await createPostPromise(myRoutes.gardiensCrud, {requestType: "create", newData: {
                        nni: values[0],
                        nom: values[1],
                        prenom: values[2],
                    }});

                window[externalVarName].rowAdd(values, key);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + modalId.row).modal("hide");
            renderGardien();

        }

        this.validateRowEdit = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_nni");
            values[1] = _get(modalId.row + "_nom");
            values[2] = _get(modalId.row + "_prenom");

            try{
                const result = await createPostPromise(myRoutes.gardiensCrud, {requestType: "update", newData: {
                    nni: values[0],
                    nom: values[1],
                    prenom: values[2],
                    idgardien: this.data()[this.keyIndex().get(key)][1][3]
                }});

                window[externalVarName].rowEdit(key, values);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + modalId.row).modal("hide");
            renderGardien();

        }

        this.validateRowDel = async function(key){

            try{
                const result = await createPostPromise(myRoutes.gardiensCrud, {
                    requestType: "delete", id: this.data()[this.keyIndex().get(key)][1][3]
                });

                window[externalVarName].rowDel(key);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + config.modalDelId).modal("hide");
            renderGardien();

        }

    }
}

class SimpleTableEditorWrapperListeDiffusion extends SimpleTableEditor{
    constructor(config, myData = [], header, externalVarName, modalId){
        super(config, myData, header, externalVarName);

        this.showRowAdd = function(key){
            document.getElementById(modalId.row + "_title").innerText = config.modalRowAddTitle;

            document.getElementById(modalId.row + "_mail").value = "";

            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowAdd('${key}');"> Valider la création</button>`;
            document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            $("#" + modalId.row).modal("show");
        }

        this.showRowEdit = function(key){

            document.getElementById(modalId.row + "_title").innerText = config.modalRowEditTitle;

            if(this.keyIndex().has(key)){
                document.getElementById(modalId.row + "_mail").value = this.data()[this.keyIndex().get(key)][1][0];

                const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowEdit('${key}');"> Valider l'édition</button>`;
                document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            }else{
                document.getElementById(modalId.row + "_txt").value = "Error";
            }

            $("#" + modalId.row).modal("show");

        }

        this.showRowDel = function(key){
            document.getElementById(config.modalDelId + "_title").innerText = config.modalRowDelTitle;

            document.getElementById(config.modalDelId + "_mail").value = this.data()[this.keyIndex().get(key)][1][0];

            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowDel('${key}');"> Valider la suppression </button>`;
            document.getElementById(config.modalDelId + "_validate").innerHTML = htmlValue;
            $("#" + config.modalDelId).modal("show");
        }

        this.validateRowAdd = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_mail");

            // request db
            try{
                const result = await createPostPromise(myRoutes.listeDiffusionCrud, {requestType: "create", newData: {
                    mail: values[0],
                }});

                window[externalVarName].rowAdd(values, key);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + modalId.row).modal("hide");
            renderlisteDiffusion();

        }

        this.validateRowEdit = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_mail");

            try{
                const result = await createPostPromise(myRoutes.listeDiffusionCrud, {requestType: "update", newData: {
                    mail: values[0],
                    idmail: this.data()[this.keyIndex().get(key)][1][1]
                }});

                window[externalVarName].rowEdit(key, values);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + modalId.row).modal("hide");
            renderlisteDiffusion();

        }

        this.validateRowDel = async function(key){

            try{
                const result = await createPostPromise(myRoutes.listeDiffusionCrud, {
                    requestType: "delete", idmail: this.data()[this.keyIndex().get(key)][1][1]
                });

                window[externalVarName].rowDel(key);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + config.modalDelId).modal("hide");
            renderlisteDiffusion();

        }

    }
}

class SimpleTableEditorWrapperBloques extends SimpleTableEditor{
    constructor(config, myData = [], header, externalVarName, modalId){
        super(config, myData, header, externalVarName);

        this.showRowAdd = function(key){
            document.getElementById(modalId.row + "_title").innerText = config.modalRowAddTitle;

            document.getElementById(modalId.row + "_nom").value = "";
            document.getElementById(modalId.row + "_prenom").value = "";
            document.getElementById(modalId.row + "_nni").value = "";
            document.getElementById(modalId.row + "_contammin").value = "";
            document.getElementById(modalId.row + "_contammax").value = "";


            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowAdd('${key}');"> Valider la création</button>`;
            document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            $("#" + modalId.row).modal("show");
        }

        this.showRowEdit = function(key){

            document.getElementById(modalId.row + "_title").innerText = config.modalRowEditTitle;

            if(this.keyIndex().has(key)){
                document.getElementById(modalId.row + "_nom").value = this.data()[this.keyIndex().get(key)][1][0];
                document.getElementById(modalId.row + "_prenom").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_nni").value = this.data()[this.keyIndex().get(key)][1][2];
                document.getElementById(modalId.row + "_contammin").value = this.data()[this.keyIndex().get(key)][1][3];
                document.getElementById(modalId.row + "_contammax").value = this.data()[this.keyIndex().get(key)][1][4];

                const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowEdit('${key}');"> Valider l'édition</button>`;
                document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            }else{
                document.getElementById(modalId.row + "_txt").value = "Error";
            }

            $("#" + modalId.row).modal("show");

        }

        this.showRowDel = function(key){
            document.getElementById(config.modalDelId + "_title").innerText = config.modalRowDelTitle;

            document.getElementById(config.modalDelId + "_nom").value = this.data()[this.keyIndex().get(key)][1][0];
            document.getElementById(config.modalDelId + "_prenom").value = this.data()[this.keyIndex().get(key)][1][1];
            document.getElementById(config.modalDelId + "_nni").value = this.data()[this.keyIndex().get(key)][1][2];
            document.getElementById(config.modalDelId + "_contammin").value = this.data()[this.keyIndex().get(key)][1][3];
            document.getElementById(config.modalDelId + "_contammax").value = this.data()[this.keyIndex().get(key)][1][4];

            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowDel('${key}');"> Valider la suppression </button>`;
            document.getElementById(config.modalDelId + "_validate").innerHTML = htmlValue;
            $("#" + config.modalDelId).modal("show");
        }

        this.validateRowAdd = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_nom");
            values[1] = _get(modalId.row + "_prenom");
            values[2] = _get(modalId.row + "_nni");
            values[3] = _get(modalId.row + "_contammin");
            values[4] = _get(modalId.row + "_contammax");

            // request db
            try{
                const result = await createPostPromise(myRoutes.bloquesCrud, {requestType: "create", newData: {
                        nom: values[0],
                        prenom: values[1],
                        nni: values[2],
                        contammin: values[3],
                        contammax: values[4],
                    }});

                window[externalVarName].rowAdd(values, key);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + modalId.row).modal("hide");
            renderBloques();

        }

        this.validateRowEdit = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_nom");
            values[1] = _get(modalId.row + "_prenom");
            values[2] = _get(modalId.row + "_nni");
            values[3] = _get(modalId.row + "_contammin");
            values[4] = _get(modalId.row + "_contammax");

            try{
                const result = await createPostPromise(myRoutes.bloquesCrud, {requestType: "update", newData: {
                        nom: values[0],
                        prenom: values[1],
                        nni: values[2],
                        contammin: values[3],
                        contammax: values[4],
                        idbloque: this.data()[this.keyIndex().get(key)][1][5]
                    }});

                window[externalVarName].rowEdit(key, values);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + modalId.row).modal("hide");
            //renderBloques();

        }

        this.validateRowDel = async function(key){

            try{
                const result = await createPostPromise(myRoutes.bloquesCrud, {
                    requestType: "delete", idbloque: this.data()[this.keyIndex().get(key)][1][5]
                });

                window[externalVarName].rowDel(key);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + config.modalDelId).modal("hide");
            renderBloques();

        }

    }
}
function createPromise(urlKey){
    return new Promise((resolve, reject) => {
        $.get(urlKey, function (data, status, xhr) {
            if (status === 'success') {
                resolve([urlKey, data]);
            } else {
                reject();
            }
        })
    })
}

function createPostPromise(urlKey, data){
    // console.log(data);
    return new Promise((resolve, reject) => {
        $.post(urlKey, data, function (data, status, xhr) {
            if (status === 'success') {
                // console.log(data);
                resolve([urlKey, data]);
            } else {
                reject();
            }
        })
    })
}

function _get(id){

    var el = document.getElementById(id);
    var result = "";

    if(el){
        if(el.value){
            result = el.value;
        }else{
            return false;
        }
    }else{
        return false;
    }

    return result;
}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function checkCookie() {
    var username = getCookie("username");
    if (username != "") {
        alert("Welcome again " + username);
    } else {
        username = prompt("Please enter your name:", "");
        if (username != "" && username != null) {
            setCookie("username", username, 365);
        }
    }
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
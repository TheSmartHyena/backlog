async function displayCharts(){

    /*createPromise(myRoutes.getAllData)
        .then( result =>{ renderData(result[1]) })
        .catch(err => { console.log(err); })*/

    /*createPromise(myRoutes.selectByBat)
        .then( (result)=>{

            let labels = [];
            let series = [];

            for(let i=0; i < result[1].result.length; i++){
                labels.push(result[1].result[i].nom);
                series.push(Number(result[1].result[i].count));
            }

            chartConfigTwo.labels = labels;
            chartConfigTwo.series = series;

            var chartTwo = new ApexCharts(document.querySelector("#contamineParMoisPie"), chartConfigTwo);
            chartTwo.render();

        })
        .catch(err => console.log(err))*/


    /*createPromise(myRoutes.nbContaminedPerMonth)
        .then(result => {

            const data1 = sortTimestampArrMap(convertToTimestamp(result[1].passesPerMonth));
            const data2 = sortTimestampArrMap(convertToTimestamp(result[1].contaminedPerMonth));

            var chartPassagesC2 = new ApexCharts(
                document.querySelector("#contamineParMoisLine"),
                newOptionsLineChart
            );

            chartPassagesC2.render();


        }).catch(err => console.log(err))*/

}

// changer data from [{key: value}] to Map(key, value)
function formatData(data){
    const result = new Map();
    data.forEach(el => result.set(el[0], el[1].value));
    return result;
}

/*function renderData(toRender){

    const toRenderMap = new Map(toRender);

    toRenderMap.forEach((value, key)=>{
        document.getElementById(key).innerText = value;
    })

}*/

/*const locales = [{
    "name": "fr",
    "options": {
        "months": ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"],
        "shortMonths": ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juill.", "août", "sept.", "oct.", "nov.", "déc."],
        "days": ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"],
        "shortDays": ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."],
        "toolbar": {
            "exportToSVG": "Télécharger au format SVG",
            "exportToPNG": "Télécharger au format PNG",
            "menu": "Menu",
            "selection": "Sélection",
            "selectionZoom": "Sélection et zoom",
            "zoomIn": "Zoomer",
            "zoomOut": "Dézoomer",
            "pan": "Navigation",
            "reset": "Réinitialiser le zoom"
        }
    }
}]*/

function convertToTimestamp(toConvert) {

    let result = []
    for(el of toConvert){
        result.push([new Date(el[0]).getTime(), el[1]])
    }

    return result
}

function sortTimestampArrMap(toSort){
    for(let i = 0; i < toSort.length; i++){
        for (let j = 1; j < toSort.length; j++) {

            if(toSort[j-1][0] > toSort[j][0]){
                const temp = toSort[j]
                toSort[j] = toSort[j-1]
                toSort[j-1] = temp
            }

        }
    }

    return toSort

}

function updatedPrecision(values, handle, unencoded, tap, positions){

    let value = Number(values[0]);

    if(value === 1){
        document.getElementById("weekCol").style.display = "none";
        document.getElementById("dayCol").style.display = "none";
    }

    renderDayWeek(value);

    // request time
    renderAllCharts();
}

function renderDayWeek(value){
    renderWeek(value);
    renderDay(value);
}

function renderWeek(value){

    if(value > 1){
        document.getElementById("weekCol").style.display = "block";
        document.getElementById("dayCol").style.display = "none";

        document.getElementById('sliderWeek').noUiSlider = null;
        document.getElementById('sliderWeek').innerHTML = "";

        sliderWeek("Two");
    }

}

function renderDay(value){

    if(value > 2){
        document.getElementById("weekCol").style.display = "block";
        document.getElementById("dayCol").style.display = "block";

        // reset and work
        document.getElementById('sliderWeek').noUiSlider = null;
        document.getElementById('sliderWeek').innerHTML = "";
        document.getElementById('sliderDay').noUiSlider = null;
        document.getElementById('sliderDay').innerHTML = "";
        sliderWeek("One");
        sliderDay();
    }

}

function updatedOneWeeks(values=[1, 52], handle, unencoded, tap, positions){
    document.getElementById("selectedWeeks").innerText = "La semaine " + Number(values[0]) + " est séléctionnée";
}

function updatedEndWeeks(values, handle, unencoded, tap, positions){

    // update days select
    document.getElementById('sliderDay').noUiSlider = null;
    document.getElementById('sliderDay').innerHTML = "";
    sliderDay();

    // request time
    renderAllCharts();
}

function getSelectedConfig(){

    var yearValue = Number(document.getElementById('selectYear').value);
    var sliderPrecisionValue = Number(window.precisionSlider.get());
    var sliderWeekValue = -1;
    var sliderDaysValue = -1;

    if(sliderPrecisionValue > 1){

        sliderWeekValue = window.weekSlider.get();
        if(typeof sliderWeekValue === "string"){
            sliderWeekValue = Number(sliderWeekValue);
        }

        if(sliderWeekValue.length > 0){
            sliderWeekValue[0] = Number(sliderWeekValue[0]);
            sliderWeekValue[1] = Number(sliderWeekValue[1]);
        }
    }

    if(sliderPrecisionValue > 2){
        sliderDaysValue = window.daySlider.get();
        if(sliderDaysValue.length > 0){
            for(let i=0; i<sliderDaysValue.length; i++) {
                sliderDaysValue[i] = Number(sliderDaysValue[i]);
            }
        }
    }

    var result = {
        precision: sliderPrecisionValue,
        year: yearValue,
        weeks: sliderWeekValue,
        days: sliderDaysValue
    }

    return result;

}

function updatedYear(){

    let precisionValue = Number(window.precisionSlider.get());
    renderDayWeek(precisionValue);

    // request time
    renderAllCharts();
}

function updatedWeeks(values=[1, 52], handle, unencoded, tap, positions){
    document.getElementById("selectedWeeks").innerText = "Les semaines " + Number(values[0]) + " à " + Number(values[1]) + " sont séléctionnées";
}

function updatedDays(values, handle, unencoded, tap, positions){
    // request time
    renderAllCharts();
}

async function renderAllCharts(){

    const config = getSelectedConfig();
    // console.log(config);

    try{
        const result = await createPostPromise(myRoutes.getDataByConfig, {config: config});
        //console.log(result);
        if(result[1].error) {
            // console.log("Crousti bug");
        }else{
            renderGlobal(result[1]);
            renderPasses(config, result[1]);
            renderContamByBat(result[1]);
        }
    }catch(err){
        console.log(err);
    }

}

function renderGlobal(result){

    document.getElementById("nbPassesDelta").innerText = result.nbPassagesDelta[0].count;
    document.getElementById("nbContaminedDelta").innerText = result.nbContamDelta[0].count;
    document.getElementById("ratioContaminedDelta").innerText = round2(100 * result.nbContamDelta[0].count / result.nbPassagesDelta[0].count);

}

function round2(x){
    return Number.parseFloat(x).toFixed(2);
}

function renderPasses(config, result){

    let passesSeries = [];
    let ratioSeries = [];
    let contaminesSeries = [];
    let labels = [];

    passesSeries = getPassesSeries(result.passagesContamResults);
    contaminesSeries = getContaminesSeries(result.passagesContamResults);
    ratioSeries = getRatioSeries(result.passagesContamResults);
    labels = getLabels2(result.passagesContamResults);

    console.log(passesSeries);
    console.log(contaminesSeries);
    console.log(ratioSeries);
    console.log(labels);

    // 0,1,2 ==> passages, contaminés, taux
    //newOptionsLineChart.series[0] = {name: "Nb passages C2", data: passesSeries, type:'column'};
    //newOptionsLineChart.series[1] = {name: "Nb contaminés C2", data: contaminesSeries, type:'column'};
    //newOptionsLineChart.series[2] = {name: "Taux contaminés C2", data: ratioSeries, type: 'line'};
    //newOptionsLineChart.xaxis.categories = labels;

    const chartPassesRatio = new ApexCharts(document.querySelector("#chartPassesRatio"), newOptionsLineChart);
    chartPassesRatio.render();

}

function getPassesSeries(items){

    let result = [];
    for(item of items){
        result.push(Number(item.nbPassagesDelta[0].count));
    }
    return result;
}

function getContaminesSeries(items){
    let result = [];
    for(item of items){
        result.push(Number(item.nbContamDelta[0].count));
    }
    return result;
}

function getRatioSeries(items){
    let result = [];
    for(item of items){

        const nbContamDelta = Number(item.nbContamDelta[0].count);
        const nbPassagesDelta = Number(item.nbPassagesDelta[0].count);

        let ratio = 0;
        if(nbContamDelta > 0 && nbPassagesDelta > 0){
            ratio = round2(100 * nbContamDelta / nbPassagesDelta);
        }
        //console.log(ratio);
        result.push(ratio);
    }
    return result;
}

function getLabels1(){

}

function getLabels2(items){
    let result = [];
    for(item of items){
        result.push(item.label);
    }
    return result;
}

function getLabels3(){

}





function renderContamByBat(result){

}

function formatC2Result(){

}
































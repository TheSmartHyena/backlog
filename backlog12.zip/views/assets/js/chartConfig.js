var chartConfigOne = {
    chart: {
        height: 350,
        type: 'line',
        shadow: {
            enabled: true,
            color: '#000',
            top: 18,
            left: 7,
            blur: 10,
            opacity: 1
        },
        toolbar: {
            show: false
        }

    },

}

var chartConfigTwo = {
    chart: {
        height: 380,
        type: 'donut',
    },
    dataLabels: {
        enabled: true
    },
    tooltip: {
        enabled: true,
        y: {
            formatter: function(val) {
                return val + " contaminés" ;
            },
            title: {
                formatter: function (seriesName) {
                    return seriesName;
                }
            }
        }
    },
    responsive: [{
        breakpoint: 480,
        options: {
            chart: {
                width: 200
            },
            legend: {
                position: 'bottom'
            }
        }
    }],
    labels: {
        total: {
            show: false,
            showAlways: false,
            label: 'Total',
            color: '#373d3f',
            formatter: function (w) {
                return w.globals.seriesTotals.reduce((a, b) => {
                    return a + b
                }, 0)
            }
        }
    }
}


/*chart: {
    defaultLocale: 'fr',
        locales: [{
        name: 'fr',
        options: {
            months: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'],
            shortMonths: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'],
            days: ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Dimanche', 'Samedi'],
            shortDays: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Dim', 'Sam'],
            toolbar: {
                download: 'Download SVG',
                selection: 'Selection',
                selectionZoom: 'Selection Zoom',
                zoomIn: 'Zoom In',
                zoomOut: 'Zoom Out',
                pan: 'Panning',
                reset: 'Reset Zoom',
            }
        }
    }]
}*/
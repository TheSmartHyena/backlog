class SimpleTableEditorWrapperUsers extends SimpleTableEditor{
    constructor(config, myData = [], header, externalVarName, modalId){
        super(config, myData, header, externalVarName);

        this.showRowAdd = function(key){
            document.getElementById(modalId.row + "_title").innerText = config.modalRowAddTitle;

            document.getElementById(modalId.row + "_nni").value = "";
            document.getElementById(modalId.row + "_password").value = "";
            document.getElementById(modalId.row + "_nom").value = "";
            document.getElementById(modalId.row + "_prenom").value = "";
            document.getElementById(modalId.row + "_mail").value = "";
            document.getElementById(modalId.row + "_service").value = "";
            document.getElementById(modalId.row + "_entreprise").value = "";
            document.getElementById(modalId.row + "_idgroupe").value = "";

            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowAdd('${key}');"> Valider </button>`;
            document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            $("#" + modalId.row).modal("show");
        }

        this.showRowEdit = function(key){

            document.getElementById(modalId.row + "_title").innerText = config.modalRowEditTitle;

            if(this.keyIndex().has(key)){
                document.getElementById(modalId.row + "_nni").value = this.data()[this.keyIndex().get(key)][1][0];
                document.getElementById(modalId.row + "_password").disabled = true;
                document.getElementById(modalId.row + "_nom").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_prenom").value = this.data()[this.keyIndex().get(key)][1][2];
                document.getElementById(modalId.row + "_mail").value = this.data()[this.keyIndex().get(key)][1][3];
                document.getElementById(modalId.row + "_service").value = this.data()[this.keyIndex().get(key)][1][4];
                document.getElementById(modalId.row + "_entreprise").value = this.data()[this.keyIndex().get(key)][1][5];
                document.getElementById(modalId.row + "_idgroupe").value = this.data()[this.keyIndex().get(key)][1][6];

                const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowEdit('${key}');"> Valider </button>`;
                document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            }else{
                document.getElementById(modalId.row + "_txt").value = "Error";
            }

            $("#" + modalId.row).modal("show");

        }

        this.showRowDel = function(key){
            document.getElementById(config.modalDelId + "_title").innerText = config.modalRowDelTitle;

            document.getElementById(config.modalDelId + "_nni").value = this.data()[this.keyIndex().get(key)][1][0];
            document.getElementById(config.modalDelId + "_nom").value = this.data()[this.keyIndex().get(key)][1][1];
            document.getElementById(config.modalDelId + "_prenom").value = this.data()[this.keyIndex().get(key)][1][2];
            document.getElementById(config.modalDelId + "_mail").value = this.data()[this.keyIndex().get(key)][1][3];
            document.getElementById(config.modalDelId + "_service").value = this.data()[this.keyIndex().get(key)][1][4];
            document.getElementById(config.modalDelId + "_entreprise").value = this.data()[this.keyIndex().get(key)][1][5];
            document.getElementById(config.modalDelId + "_idgroupe").value = this.data()[this.keyIndex().get(key)][1][6];

            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowDel('${key}');"> Valider la suppression </button>`;
            document.getElementById(config.modalDelId + "_validate").innerHTML = htmlValue;
            $("#" + config.modalDelId).modal("show");
        }

        this.validateRowAdd = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_nni");
            values[1] = _get(modalId.row + "_nom");
            values[2] = _get(modalId.row + "_prenom");
            values[3] = _get(modalId.row + "_mail");
            values[4] = _get(modalId.row + "_service");
            values[5] = _get(modalId.row + "_entreprise");
            values[6] = _get(modalId.row + "_idgroupe");
            values[7] = _get(modalId.row + "_password");

            // request db
            try{
                const result = await createPostPromise(myRoutes.usersCrud, {requestType: "create", newData: {
                    nni: values[0],
                    nom: values[1],
                    prenom: values[2],
                    mail: values[3],
                    service: values[4],
                    entreprise: values[5],
                    idgroupe: values[6],
                    password: values[7]
                }});

                window[externalVarName].rowAdd(values, key);
                window[externalVarName].render();

            }catch(err){
                console.log(err);
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + modalId.row).modal("hide");
            displayUsers();

        }

        this.validateRowEdit = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_nni");
            values[1] = _get(modalId.row + "_nom");
            values[2] = _get(modalId.row + "_prenom");
            values[3] = _get(modalId.row + "_mail");
            values[4] = _get(modalId.row + "_service");
            values[5] = _get(modalId.row + "_entreprise");
            values[6] = _get(modalId.row + "_idgroupe");

            try {
                const result = await createPostPromise(myRoutes.usersCrud, {
                    requestType: "update", newData: {
                        id: this.data()[this.keyIndex().get(key)][1][7],
                        nni: values[0],
                        nom: values[1],
                        prenom: values[2],
                        mail: values[3],
                        service: values[4],
                        entreprise: values[5],
                        idgroupe: values[6]
                    }
                });

                window[externalVarName].rowEdit(key, values);
                window[externalVarName].render();

            }catch(err){
                console.log(err)
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + modalId.row).modal("hide");
            displayUsers();
        }

        this.validateRowDel = async function(key){

            try{
                const result = await createPostPromise(myRoutes.usersCrud, {
                    requestType: "delete", id: this.data()[this.keyIndex().get(key)][1][7],
                });

                window[externalVarName].rowDel(key);
                window[externalVarName].render();

            }catch(err){
                console.log(err)
                alert("Une erreur s'est produite, contacter la MOA.");
            }

            $("#" + config.modalDelId).modal("hide");
            displayUsers();
        }

    }
}

async function displayUsers(){
    try{
        const result = await createPostPromise(myRoutes.usersCrud, {requestType: "readAll"});
        renderUser(result[1])
    }catch(err){
        console.log(err);
    }
}

function renderUser(data){
    const result = objToArrayMapUsers(data.value);
    usersList.load(result);
    usersList.render();
    window.usersList = usersList;
}

let usersList = (function () {

    const config = {
        nbCol: 7,
        divId: "usersList",
        btnSize: "sm",
        modalRowEditTitle: "Modification d'un utilisateur",
        modalRowAddTitle: "Ajout d'un utilisateur",
        modalRowDelTitle: "Supression d'un utilisateur",
        modalDelId: "modal_row_del_users"
    };

    const modalId = {
        row: "modal_row_users"
    }

    const result = new SimpleTableEditorWrapperUsers(config, [], ["Nni", "Nom", "Prénom", "Mail", "Service", "Entreprise", "Groupe"], "usersList", modalId);

    result.allowRowEdit(true);
    result.allowRowAdd(true);
    result.allowRowDel(true);

    return result;

})();

function objToArrayMapUsers(objs){

    const result = [];
    for(obj of objs){
        result.push(["", [obj.nni, obj.nom, obj.prenom, obj.mail, obj.service, obj.entreprise, obj.idgroupe, obj.idutilisateur]]);
    }

    return result;

}

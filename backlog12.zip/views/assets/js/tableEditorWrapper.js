class TableEditorWrapper extends TableEditor{
    constructor(config, myData = [], header, externalVarName, modalId){
        super(config, myData, header, externalVarName);

        this.showRowEdit = function(key){

            document.getElementById(modalId.row + "_title").innerText = config.modalRowEditTitle;

            if(this.keyIndex().has(key)){
                document.getElementById(modalId.row + "_key").value = this.data()[this.keyIndex().get(key)][1][0];
                document.getElementById(modalId.row + "_sql").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_sql").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_sql").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_sql").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_sql").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_sql").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_sql").value = this.data()[this.keyIndex().get(key)][1][1];

                const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowEdit('${key}');"> Valider </button>`;
                document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            }else{
                document.getElementById(modalId.row + "_txt").value = "Error";
            }

            $("#" + modalId.row).modal("show");

        }

        this.showRowAdd = function(key){
            document.getElementById(modalId.row + "_title").innerText = config.modalRowAddTitle;

            document.getElementById(modalId.row + "_key").value = "";
            document.getElementById(modalId.row + "_sql").value = "";


            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowAdd('${key}');"> Valider </button>`;
            document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            $("#" + modalId.row).modal("show");
        }

        this.validateRowEdit = function(key){
            const values = [];
            values[0] = _get(modalId.row + "_key");
            values[1] = _get(modalId.row + "_sql");

            window[externalVarName].edit(key, values);
            $("#" + modalId.row).modal("hide");
        }

        this.validateRowAdd = function(key){

            const values = [];
            values[0] = _get(modalId.row + "_key");
            values[1] = _get(modalId.row + "_sql");

            window[externalVarName].rowAdd(values, key);
            $("#" + modalId.row).modal("hide");
        }
        
        this.showColEdit = function(){
            document.getElementById(modalId.col).modal("show");

        }
        this.showColAdd = function(){
            document.getElementById(modalId.col).modal("show");

        }
        this.validateColEdit = function(){
            document.getElementById(modalId.col).modal("hide");
        }
        this.validateColAdd = function(){
            document.getElementById(modalId.col).modal("hide");
        }

    }
}

class TableEditorWrapperBloques extends TableEditor{
    constructor(config, myData = [], header, externalVarName, modalId){
        super(config, myData, header, externalVarName);

        this.showRowEdit = function(key){

            document.getElementById(modalId.row + "_title").innerText = config.modalRowEditTitle;

            if(this.keyIndex().has(key)){
                document.getElementById(modalId.row + "_nni").value = this.data()[this.keyIndex().get(key)][1][0];
                document.getElementById(modalId.row + "_nom").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_prenom").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_contammin").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_contammax").value = this.data()[this.keyIndex().get(key)][1][1];

                const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowEdit('${key}');"> Valider </button>`;
                document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            }else{
                document.getElementById(modalId.row + "_nni").value = "Error";

            }

            $("#" + modalId.row).modal("show");

        }

        this.showRowAdd = function(key){
            document.getElementById(modalId.row + "_title").innerText = config.modalRowAddTitle;

            document.getElementById(modalId.row + "_nni").value = "";
            document.getElementById(modalId.row + "_nom").value = "";
            document.getElementById(modalId.row + "_prenom").value = "";
            document.getElementById(modalId.row + "_contammin").value = "";
            document.getElementById(modalId.row + "_contammax").value = "";


            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowAdd('${key}');"> Valider </button>`;
            document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            $("#" + modalId.row).modal("show");
        }

        this.validateRowEdit = function(key){
            const values = [];
            values[0] = _get(modalId.row + "_nni");
            values[1] = _get(modalId.row + "_nom");
            values[2] = _get(modalId.row + "_prenom");
            values[3] = _get(modalId.row + "_contammin");
            values[4] = _get(modalId.row + "_contammax");

            window[externalVarName].edit(key, values);
            $("#" + modalId.row).modal("hide");
        }

        this.validateRowAdd = function(key){

            const values = [];
            values[0] = _get(modalId.row + "_nni");
            values[1] = _get(modalId.row + "_nom");
            values[2] = _get(modalId.row + "_prenom");
            values[3] = _get(modalId.row + "_contammin");
            values[4] = _get(modalId.row + "_contammax");

            window[externalVarName].rowAdd(values, key);
            $("#" + modalId.row).modal("hide");
        }

        this.showColEdit = function(){
            document.getElementById(modalId.col).modal("show");

        }
        this.showColAdd = function(){
            document.getElementById(modalId.col).modal("show");

        }
        this.validateColEdit = function(){
            document.getElementById(modalId.col).modal("hide");
        }
        this.validateColAdd = function(){
            document.getElementById(modalId.col).modal("hide");
        }

    }
}

class TableEditorWrapperGardien extends TableEditor{
    constructor(config, myData = [], header, externalVarName, modalId){
        super(config, myData, header, externalVarName);

        this.showRowEdit = function(key){

            document.getElementById(modalId.row + "_title").innerText = config.modalRowEditTitle;

            if(this.keyIndex().has(key)){
                document.getElementById(modalId.row + "_nni").value = this.data()[this.keyIndex().get(key)][1][0];
                document.getElementById(modalId.row + "_nom").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_prenom").value = this.data()[this.keyIndex().get(key)][1][1];

                const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowEdit('${key}');"> Valider </button>`;
                document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            }else{
                document.getElementById(modalId.row + "_nni").value = "Error";

            }

            $("#" + modalId.row).modal("show");

        }

        this.showRowAdd = function(key){
            document.getElementById(modalId.row + "_title").innerText = config.modalRowAddTitle;

            document.getElementById(modalId.row + "_nni").value = "";
            document.getElementById(modalId.row + "_nom").value = "";
            document.getElementById(modalId.row + "_prenom").value = "";

            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowAdd('${key}');"> Valider </button>`;
            document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            $("#" + modalId.row).modal("show");
        }

        this.validateRowEdit = function(key){
            const values = [];
            values[0] = _get(modalId.row + "_nni");
            values[1] = _get(modalId.row + "_nom");
            values[2] = _get(modalId.row + "_prenom");

            window[externalVarName].edit(key, values);
            $("#" + modalId.row).modal("hide");
        }

        this.validateRowAdd = function(key){

            const values = [];
            values[0] = _get(modalId.row + "_nni");
            values[1] = _get(modalId.row + "_nom");
            values[2] = _get(modalId.row + "_prenom");

            window[externalVarName].rowAdd(values, key);
            $("#" + modalId.row).modal("hide");
        }

        this.showColEdit = function(){
            document.getElementById(modalId.col).modal("show");

        }
        this.showColAdd = function(){
            document.getElementById(modalId.col).modal("show");

        }
        this.validateColEdit = function(){
            document.getElementById(modalId.col).modal("hide");
        }
        this.validateColAdd = function(){
            document.getElementById(modalId.col).modal("hide");
        }

    }
}

class TableEditorWrapperListeDiffusion extends TableEditor{
    constructor(config, myData = [], header, externalVarName, modalId){
        super(config, myData, header, externalVarName);

        this.showRowEdit = function(key){

            document.getElementById(modalId.row + "_title").innerText = config.modalRowEditTitle;

            if(this.keyIndex().has(key)){
                document.getElementById(modalId.row + "_mail").value = this.data()[this.keyIndex().get(key)][1][0];

                const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowEdit('${key}');"> Valider </button>`;
                document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            }else{
                document.getElementById(modalId.row + "_mail").value = "Error";

            }

            $("#" + modalId.row).modal("show");

        }

        this.showRowAdd = function(key){
            document.getElementById(modalId.row + "_title").innerText = config.modalRowAddTitle;

            document.getElementById(modalId.row + "_mail").value = "";

            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowAdd('${key}');"> Valider </button>`;
            document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            $("#" + modalId.row).modal("show");
        }

        this.validateRowEdit = function(key){
            const values = [];
            values[0] = _get(modalId.row + "_mail");

            window[externalVarName].edit(key, values);
            $("#" + modalId.row).modal("hide");
        }

        this.validateRowAdd = function(key){

            const values = [];
            values[0] = _get(modalId.row + "_mail");

            window[externalVarName].rowAdd(values, key);
            $("#" + modalId.row).modal("hide");
        }

    }
}
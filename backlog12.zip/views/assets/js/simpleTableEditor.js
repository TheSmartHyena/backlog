/*
    CONFIG {}

    - divId
    - nbCol

*/

/*
    Data: [
        key, [col1, col2, col3],
        key2, [col1, col2, col3],
        key3, [col1, col2, col3]
    ]
*/

// externalVarName ==> the name of the instance, wich will be used to use the class
class SimpleTableEditor{
    constructor(config, data = [], header, externalVarName) {

        let myAllowRowAdd = true;
        let myAllowRowEdit = true;
        let myAllowRowDel = true;

        // associate a key with it's row number ==> fasten edit
        let myKeyIndex = new Map();
        this.keyIndex = function () {
            return myKeyIndex;
        }

        let myData = data ? data : [];
        this.data = function () {
            return myData;
        }

        // import and generate internal key
        this.load = function (data) {
            myData = data ? data : [];
            if (myData.length > 0) {
                for (let i = 0; i < myData.length; i++) {
                    const key = guidGenerator();
                    myData[i][0] = key;
                    myKeyIndex.set(key, i);
                }
            }
        }

        function guidGenerator() {
            let S4 = function () {
                return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
            };
            return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
        }

        this.release = function () {
            document.getElementById(config.divId).innerHTML = "";
        }

        // export without internal key
        this.export = function () {
            let result = JSONparse(SON.stringify(myData));

            for (let i = 0; i < myData.length; i++) {
                myData[i][0] = "";
            }

            return result;
        }

        this.render = function () {

            let headerStart = '<div class="table-wrapper"><div class="table-scroll"><table class="table table-striped text-center maxHeighted"><thead><tr>';
            let headerEnd = '</tr></thead>';

            let bodyStart = '<tbody>';
            let bodyEnd = '</tbody></table> </div></div>';

            let headerContent = '';
            for (let i = 0; i < config.nbCol; i++) {
                headerContent = headerContent + '<th>' + header[i] + '</th>';
            }

            if (myAllowRowAdd && myData.length === 0) {
                headerContent = headerContent + '<th> Contrôles </th>';
            }

            if ((myAllowRowEdit ||  myAllowRowDel || myAllowRowAdd) && myData.length > 0) {
                if (myAllowRowAdd) {
                    headerContent = headerContent + '<th> Contrôles ' + `<button type="button" class="btn btn-success btn-${config.btnSize}" onclick="window.${externalVarName}.showRowAdd('');"> <i class="fas fa-plus"></i> </button>` +  '</th>';
                }else{
                    headerContent = headerContent + '<th> Contrôles </th>';
                }


            }

            let bodyContent = '';
            for (let i = 0; i < myData.length; i++) {

                // console.log(myData[i]);

                bodyContent = bodyContent + '<tr>';
                for (let j = 0; j < config.nbCol; j++) {
                    bodyContent = bodyContent + '<td>' + myData[i][1][j] + '</td>';
                }

                if (config.nbCol === 0) {
                    bodyContent = bodyContent + '<td> --- </td>';
                }

                if (myAllowRowEdit || myAllowRowDel || myAllowRowAdd) {
                    bodyContent = bodyContent + '<td class="text-center">' + generateRowControls(myData[i][0]) + '</td>';
                }

                bodyContent = bodyContent + '<tr>';
            }

            let lastRowWithControls = generateColControls();

            const tableHtml = headerStart + headerContent + headerEnd + bodyStart + bodyContent + lastRowWithControls + bodyEnd;

            document.getElementById(config.divId).innerHTML = tableHtml;

        }

        function generateRowControls(key, size = "sm") {

            let result = '';
            if (myAllowRowEdit && config.nbCol > 0) {
                result = result + `<button type="button" class="btn btn-warning btn-${config.btnSize}" onclick="window.${externalVarName}.showRowEdit('${key}');"> <i class="fas fa-edit"></i> </button>`;
            }

            if (myAllowRowDel) {
                result = result + `<button type="button" class="btn btn-danger btn-${config.btnSize}" onclick="window.${externalVarName}.showRowDel('${key}');"> <i class="fas fa-trash-alt"></i> </button>`;
            }

            /*
            if (myAllowRowAdd) {
                result = result + `<button type="button" class="btn btn-success btn-${config.btnSize}" onclick="window.${externalVarName}.showRowAdd('${key}');"> <i class="fas fa-plus"></i> </button>`;
            }
            */

            if (myAllowRowEdit || myAllowRowDel || myAllowRowAdd) {
                result = '<div class="btn-group">' + result + '</div>';
            }

            return result;
        }

        function generateColControls(){

            let result = "";
            if(myAllowRowAdd && myData.length === 0){

                for(let i = 0; i < config.nbCol; i++){
                    result = result + '<td class="text-center"> --- </td>';
                }

                result = result + '<td class="text-center">' + getColControlsNoRow() + '</td>';
                result = '<tr>' + result + '</tr>';

            }

            return result;

        }

        function getColControlsNoRow(){

            let result = '';
            if(myAllowRowAdd && config.nbCol > 0){
                result = result + '<div class="btn-group">' + `<button type="button" class="btn btn-success btn-${config.btnSize}" onclick="window.${externalVarName}.showRowAdd();"> <i class="fas fa-plus"></i> </button>` + '</div>';
            }

            return  result;
        }

        // lock-unlock
        this.allowRowEdit = function (bool) {
            myAllowRowEdit = bool;
        }

        this.allowRowAdd = function (bool) {
            myAllowRowAdd = bool;
        }

        this.allowRowDel = function (bool) {
            myAllowRowDel = bool;
        }

        this.rowAdd = function (values, keyToInsertAfter = false) {

            if (myAllowRowAdd) {
                if (values.length == config.nbCol) {

                    let key = guidGenerator();
                    let newArr = [key, values];

                    myData[myData.length] = newArr;
                    myKeyIndex.set(key, myData.length - 1);

                    this.render();

                    return key;

                } else {
                    console.log("Number of columns does not match");
                    return false;
                }
            } else {
                console.log("Action currently locked");
            }

        }

        this.rowDel = function (key) {

            if (myAllowRowDel) {
                if (myKeyIndex.has(key)) {

                    myData.splice(myKeyIndex.get(key), 1);

                    myKeyIndex.clear();
                    if (myData.length > 0) {
                        for (let i = 0; i < myData.length; i++) {
                            myKeyIndex.set(myData[i][0], i);
                        }
                    }

                    // keyIndex.forEach((value, key)=>{
                    //     console.log(key + " - " + value);
                    // });
                    this.render();

                } else {
                    console.log("Selected key does not exist");
                }
            } else {
                console.log("Action currently locked");
            }

        }

        this.rowEdit = function (key, newValues) {
            if (myAllowRowEdit) {
                if (myKeyIndex.has(key)) {
                    if (newValues.length == config.nbCol) {
                        myData[myKeyIndex.get(key)][1] = newValues;
                        this.render();
                    } else {
                        console.log("Number of columns does not match");
                    }
                } else {
                    console.log("Selected key does not exist");
                }
            } else {
                console.log("Action currently locked");
            }

        }
    }

    keyIndex() {
        return this.keyIndex();
    }
}
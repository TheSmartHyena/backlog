class SimpleTableEditorWrapperNoteService extends SimpleTableEditor{
    constructor(config, myData = [], header, externalVarName, modalId){
        super(config, myData, header, externalVarName);

        const mySuperKeyIndex = super.keyIndex();

        this.showRowAdd = function(key){
            document.getElementById(modalId.row + "_title").innerText = config.modalRowAddTitle;

            document.getElementById(modalId.row + "_id").value = "";
            document.getElementById(modalId.row + "_serviceId").value = "";
            document.getElementById(modalId.row + "_note").value = "";


            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowAdd('${key}');"> Valider </button>`;
            document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            $("#" + modalId.row).modal("show");
        }

        this.showRowEdit = function(key){

            document.getElementById(modalId.row + "_title").innerText = config.modalRowEditTitle;

            if(this.keyIndex().has(key)){
                document.getElementById(modalId.row + "_id").value = this.data()[this.keyIndex().get(key)][1][0];
                document.getElementById(modalId.row + "_serviceId").value = this.data()[this.keyIndex().get(key)][1][1];
                document.getElementById(modalId.row + "_note").value = this.data()[this.keyIndex().get(key)][1][2];

                const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowEdit('${key}');"> Valider </button>`;
                document.getElementById(modalId.row + "_validate").innerHTML = htmlValue;
            }else{
                document.getElementById(modalId.row + "_txt").value = "Error";
            }

            $("#" + modalId.row).modal("show");

        }

        this.showRowDel = function(key){
            document.getElementById(config.modalDelId + "_title").innerText = config.modalRowDelTitle;

            document.getElementById(config.modalDelId + "_id").value = this.data()[this.keyIndex().get(key)][1][0];
            document.getElementById(config.modalDelId + "_serviceId").value = this.data()[this.keyIndex().get(key)][1][1];
            document.getElementById(config.modalDelId + "_note").value = this.data()[this.keyIndex().get(key)][1][2];

            const htmlValue = `<button type="button" class="btn btn-success btn-{config.size}" onclick="window.${externalVarName}.validateRowDel('${key}');"> Valider la suppression </button>`;
            document.getElementById(config.modalDelId + "_validate").innerHTML = htmlValue;
            $("#" + config.modalDelId).modal("show");
        }

        this.validateRowAdd = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_id");
            values[1] = _get(modalId.row + "_serviceId");
            values[2] = _get(modalId.row + "_note");

            // request db
            try{
                const result = await createPostPromise(myRoutes.noteServiceCrud, {requestType: "create", newData: {
                        serviceId: values[1],
                        note: values[2],
                    }});

                window[externalVarName].rowAdd(values, key);
                window[externalVarName].render();

                $("#" + modalId.row).modal("hide");

                // Sale mais nécéssaire
                displayNoteService();

            }catch(err){
                alert("Une erreur s'est produite, contacter la MOA.");
                $("#" + modalId.row).modal("hide");
                document.location.reload(true);
            }

        }

        this.validateRowEdit = async function(key){

            const values = [];
            values[0] = _get(modalId.row + "_id");
            values[1] = _get(modalId.row + "_serviceId");
            values[2] = _get(modalId.row + "_note");

            const result = await createPostPromise(myRoutes.noteServiceCrud, {requestType: "update", newData: {
                    id: document.getElementById(modalId.row + "_id").value = this.data()[this.keyIndex().get(key)][1][0],
                    serviceId: values[1],
                    note: values[2]
                }});

            window[externalVarName].rowEdit(key, values);
            window[externalVarName].render();

            $("#" + modalId.row).modal("hide");
        }

        this.validateRowDel = async function(key){

            try{
                const result = await createPostPromise(myRoutes.noteServiceCrud, {
                    requestType: "delete", id: this.data()[this.keyIndex().get(key)][1][0]
                });

                window[externalVarName].rowDel(key);
                window[externalVarName].render();

                $("#" + config.modalDelId).modal("hide");
            }catch(err){
                console.log(err)
                alert("Une erreur s'est produite, contacter la MOA.");
                $("#" + config.modalDelId).modal("hide");
            }
        }

    }
}

class SimpleTableEditorWrapperNoEditNoteService extends SimpleTableEditor {
    constructor(config, myData = [], header, externalVarName, modalId) {
        super(config, myData, header, externalVarName);
    }
}

async function displayNoteService(){
    try{
        const result = await createPostPromise(myRoutes.noteServiceCrud, {requestType: "readForEdit"});
        renderNoteService(result[1])
    }catch(err){
        console.log(err);
    }
}

function renderNoteService(data){
    const result = objToArrayNoteService(data.value);
    noteServiceList.load(result);
    noteServiceList.render();
    window.noteServiceList = noteServiceList;
}

let noteServiceList = (function () {

    const config = {nbCol: 3, divId: "noteServiceList", btnSize: "sm", modalRowEditTitle: "Edition des notes de services", modalDelId: "modal_row_del_noteService", modalRowDelTitle:"Suppression" };
    const modalId = {
        row: "modal_row_noteService",
        col: "modal_col"
    }

    const result = new SimpleTableEditorWrapperNoteService(config, [], ["id", "Service", "Note"], "noteServiceList", modalId);

    result.allowRowEdit(true);
    result.allowRowAdd(true);
    result.allowRowDel(true);

    return result;

})();

function objToArrayNoteService(objs){

    const result = [];
    for(obj of objs){
        result.push(["", [obj.id, obj.serviceid, obj.note]]);
    }

    return result;

}

/**
 * No Edit Part
 */

async function displayNotEditableNoteService(){
    try{
        const result = await createPostPromise(myRoutes.noteServiceCrud, {requestType: "read"});
        renderNotEditableNoteService(result[1])
    }catch(err){
        console.log(err);
    }
}

function renderNotEditableNoteService(data){
    const result = objToArrayNoEditNoteService(data.value);
    noEditNoteServiceList.load(result);
    noEditNoteServiceList.render();
    window.noEditNoteServiceList = noEditNoteServiceList;
}

let noEditNoteServiceList = (function () {

    const config = {nbCol: 1, divId: "noteServiceNoEditList", btnSize: "sm", modalRowEditTitle: ""};
    const modalId = {
        row: "",
        col: ""
    }

    const result = new SimpleTableEditorWrapperNoEditNoteService(config, [], ["Note"], "noteServiceList", modalId);
    result.allowRowEdit(false);
    result.allowRowAdd(false);
    result.allowRowDel(false);

    return result;

})();

function objToArrayNoEditNoteService(objs){

    const result = [];
    for(obj of objs){
        result.push(["", [obj.note]]);
    }

    return result;

}
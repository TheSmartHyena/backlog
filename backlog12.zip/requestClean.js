const myRoutes = require('./routesTriggers').routes

exports.get_nbContaminedPerDay = (app, myRequired)=>{
    app.get(myRoutes.nbContaminedPerDay , async(req, res)=>{
        myRequired.custom.request.doAnRequest(myRequired, 'nbContaminedPerDay')
            .then(result => {

                let total = 0;
                result.forEach((el)=>{
                    if(el.iscontam === true){
                        total++;
                    }
                })
                res.json({value: total})
            })
            .catch(err => console.log(err))
    })
}

exports.get_passesPerDay = (app, myRequired)=>{
    app.get(myRoutes.passesPerDay, async(req, res)=>{
        myRequired.custom.request.doAnRequest(myRequired,'passesPerDay')
            .then(result => {
                res.json({value: result})

            })
            .catch(err => console.log(err))
    })
}

exports.get_nbContaminedPerMonth = (app, myRequired)=>{
    app.get(myRoutes.nbContaminedPerMonth, async(req, res)=>{
        myRequired.custom.request.doAnRequest(myRequired,'passesPerDay')
            .then(result => {

                const year = new Date().getFullYear()

                const passesPerMonth = nbContaminedPerMonth(result, false, year)
                const contaminedPerMonth = nbContaminedPerMonth(result, true, year)

                res.json({passesPerMonth: mapToArrMap(passesPerMonth), contaminedPerMonth: mapToArrMap(contaminedPerMonth)})
            })
            .catch(err => console.log(err))
    })
}

exports.get_nbContaminedPerBuildingPerDay = (app, myRequired)=>{
    app.get(myRoutes.nbContaminedPerBuildingPerDay, async(req, res) => {
        myRequired.custom.request.doAnRequest(myRequired,'nbContaminedPerBuildingPerDay')
            .then(result => res.json(result))
            .catch(err => console.log(err))
    })
}

exports.get_getAllData = (app, myRequired)=>{
    app.get(myRoutes.getAllData, async (req, res)=>{

        const data = await myRequired.custom.request.doAnRequest(myRequired,'passesPerDay')
        const result = [
            ["passesPerDay", data.length],
            ["nbContaminedPerDay", nbContaminedPerDay(data)],
            ["percentageContaminedPerDay", round2(100 * nbContaminedPerDay(data) / data.length)]
        ]

        res.json(result)

    })
}

function round2(x){
    return Number.parseFloat(x).toFixed(2);
}

exports.get_getAllUsers = (app, myRequired)=>{
    app.get(myRoutes.getAllUsers, async (req, res)=>{

        myRequired.custom.request.doAnRequest(myRequired,'getAllUsers')
            .then(result => {
                res.json({result: result})
            })
            .catch(err => console.log(err))
    })
}

exports.get_selectByBat = (app, myRequired)=>{
    app.get(myRoutes.selectByBat, async (req, res)=>{

        myRequired.custom.request.doAnRequest(myRequired,'selectByBat')
            .then(result => {
                res.json({result: result})
            })
            .catch(err => console.log(err))
    })
}

function nbContaminedPerDay(data){

    let total = 0
    data.forEach((el)=>{
        if(el.iscontam === true){
            total++
        }
    })

    return total
}

function nbContaminedPerMonth(result, contamined, year){

    const months = new Map()
    for(const el of result){
        if(el.date.includes(year)){

            for(let i = 1; i < 13; i++){

                const month = i < 10 ? `0${i}` : i
                const date = `${year}-${month}`

                if(contamined === false || (el.iscontam === true && contamined === true)){
                    if(el.date.includes(date)){
                        if(months.has(date)){
                            months.set(date, months.get(date) + 1)
                        }else{
                            months.set(date, 1)
                        }
                    }
                }

            }

        }
    }

    for(let  i = 1; i < 13; i++){

        const month = i < 10 ? `0${i}` : i
        const date = `${year}-${month}`

        if(!months.has(date)){
            months.set(date, 0)
        }

    }

    return months
}

function nbPassesPerMonth(data){

}

function nbContaminedPerBuildingPerDay(data){

}

function mapToArrMap(toConvert){

    let result = []

    toConvert.forEach((value, key)=>{
        result.push([key, value])
    })

    return result

}

exports.post_getDataByConfig = (app, myRequired)=>{
    app.post(myRoutes.getDataByConfig, async (req, res)=>{

        const momentjs = require('moment')
        momentjs.locale('fr')

        const config = req.body.config
        const deltaConfig = configToDeltaDate(momentjs, config);
        const deltaConfigs = configsToDeltaDate(momentjs, config);

        //console.log(config)
        //console.log(deltaConfigs)

        let passagesContamResults = []
        for(singleDeltaConfig of deltaConfigs){
            passagesContamResults.push({
                nbContamDelta : await getNbContamDelta(myRequired, singleDeltaConfig.start, singleDeltaConfig.end),
                nbPassagesDelta : await getNbPassagesDelta(myRequired, singleDeltaConfig.start, singleDeltaConfig.end),
                label: singleDeltaConfig.label
            })
        }

        let nbContamDeltaByBat = await getNbContamDeltaByBat(myRequired, deltaConfig.start, deltaConfig.end);

        if(passagesContamResults.length > 0){
            res.json({
                error: false,
                passagesContamResults: passagesContamResults,
                nbContamDelta : await getNbContamDelta(myRequired, deltaConfig.start, deltaConfig.end),
                nbPassagesDelta : await getNbPassagesDelta(myRequired, deltaConfig.start, deltaConfig.end),
                nbContamDeltaByBat: nbContamDeltaByBat
            })
        }else{
            res.json({error: true})
        }

    })
}

function configsToDeltaDate(momentjs, config){

    console.log(config);

    let result = [];
    switch(Number(config.precision)){

        case 1:
            result[0] = {}
            result[0].start = momentjs().year(config.year).startOf('year').format('YYYY-MM-DD HH:mm:ss')
            result[0].end = momentjs().year(config.year).endOf('year').format('YYYY-MM-DD HH:mm:ss')
            break;
        case 2:
            result = deltaWeeks(momentjs, config.year, config.weeks[0], config.weeks[1])
            break;
        case 3:
            result = deltaWeeks(momentjs, config.year, config.weeks, config.days[0], config.days[0])
            break;
        default:
            console.log("Erreur dans la valeur de la precision")
    }

    return result;
}

function configToDeltaDate(momentjs, config){

    const result = {start: -1, end: -1};
    switch(Number(config.precision)){

        case 1:
            result.start = momentjs().year(config.year).startOf('year').format('YYYY-MM-DD HH:mm:ss')
            result.end = momentjs().year(config.year).endOf('year').format('YYYY-MM-DD HH:mm:ss')
            break;
        case 2:
            result.start = momentjs().year(config.year).week(config.weeks[0]).startOf('week').format('YYYY-MM-DD HH:mm:ss')
            result.end = momentjs().year(config.year).week(config.weeks[1]).endOf('week').format('YYYY-MM-DD HH:mm:ss')
            break;
        case 3:
            result.start = momentjs().year(config.year).week(config.weeks).day(config.days[0]).startOf('day').format('YYYY-MM-DD HH:mm:ss')
            result.end = momentjs().year(config.year).week(config.weeks).day(config.days[1]).endOf('day').format('YYYY-MM-DD HH:mm:ss')
            break;
        default:
            console.log("Erreur dans la valeur de la precision")
    }

    return result;
}

function deltaWeeks(momentjs, year, start, end){
    let result = []
    for(let i=start; i<=end; i++){
        result.push({
            start: momentjs().year(year).week(i).startOf('week').format('YYYY-MM-DD HH:mm:ss'),
            end: momentjs().year(year).week(i).endOf('week').format('YYYY-MM-DD HH:mm:ss'),
            label: momentjs().year(year).week(i).format('ww')
        })
    }
    return result
}

function deltaDays(momentjs, year, week, start, end){
    let result = []
    for(let i=start; i<=end; i++){
        result.push({
            start: momentjs().year(year).week(week).day(i).startOf('day').format('YYYY-MM-DD HH:mm:ss'),
            end: momentjs().year(year).week(week).day(i).endOf('day').format('YYYY-MM-DD HH:mm:ss'),
            label: momentjs().year(year).week(week).day(i).format('DD/MM/YYYY')
        })
    }
    return result
}

async function getNbPassagesDelta(myRequired, deltaA, deltaB){

    let result = -1;

    try{
        result = await myRequired.custom.request.doAnRequest(myRequired,'nbPassagesDelta', [deltaA, deltaB] )
    }catch(err){
        console.log(err);
    }

    return result;

}

async function getNbContamDelta(myRequired, deltaA, deltaB){

    let result = -1;

    try{
        result = await myRequired.custom.request.doAnRequest(myRequired,'nbContamDelta', [deltaA, deltaB])
    }catch(err){
        console.log(err);
    }

    return result;
}

function getNbContamDeltaByBat(myRequired, deltaA, deltaB){

    let result= -1;

    return result;
}





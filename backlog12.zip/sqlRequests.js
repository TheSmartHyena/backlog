const myRoutes = require('./routesTriggers').routes

exports.get_requests = (app, myRequired) => {

    app.get(myRoutes.requests, async (req, res)=>{

        let result = []
        await myRequired.storage.forEach(function(item) {
            result.push([item.key, [item.key, item.value]])
        });

        res.json(result)

    })

}

exports.post_requests = (app, myRequired) => {

    app.post(myRoutes.requests, async (req, res)=>{

        let result = []
        await myRequired.storage.forEach(function(item) {
            result.push([item.key, [item.key, item.value]])
        });

        const mapA = new Map(result)
        const mapB = new Map( JSON.parse(req.body.items))

        // update and delete
        mapA.forEach(async (value, key)=>{
            if(mapB.has(key)){
                await myRequired.storage.updateItem(key, mapB.get(key)[1])
                mapB.get(key)[1]
            }else{
                await myRequired.storage.removeItem(key)
            }
        })

        // create new ones
        mapB.forEach(async (value, key)=>{
            if(!mapA.has(value[0])) {
                await myRequired.storage.setItem(value[0], value[1])
            }
        })

    })

}

exports.getRequest = async (app, key)=>{

    const result = await app.storage.getItem(key)
    if(result === undefined){
        return new Error("Invalid key")
    }

    return result

}

exports.setRequest = async (app, key, value) =>{
    await app.storage.setItem(key, value)
}

exports.keys = async (app) => {
    await app.storage.keys()
}